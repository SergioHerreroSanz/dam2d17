package com.pdm.p_08_eventos_01;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void metodoSumar(View view) {
        EditText editText1 = findViewById(R.id.editText);
        String valor1 = editText1.getText().toString();
        int num_caract = valor1.trim().length();
        if (num_caract == 0) {
            editText1.requestFocus();
        } else {
            EditText editText2 = findViewById(R.id.editText2);
            String valor2 = editText2.getText().toString();
            num_caract = valor2.trim().length();
            if (num_caract == 0) {
                editText2.requestFocus();
            } else {
                TextView textView = findViewById(R.id.textView2);
                double num1 = Double.parseDouble(valor1);
                double num2 = Double.parseDouble(valor2);
                double suma = num1 + num2;
                String resultado = String.valueOf(suma);
                textView.setText(resultado);
            }
        }
    }

}
