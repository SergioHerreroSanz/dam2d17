package com.pdm.p_34_spinner_intent_02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Objects;

public class SegundaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);
        if (getIntent().getExtras() != null) {
            Bundle bundle=getIntent().getExtras();
            final String cursoEscogido=bundle.getString("cursoEscogido");
            TextView textView = findViewById(R.id.textView2);
            textView.setText(String.format("Lista de asignaturas de %s", cursoEscogido));
            String[] asignaturas;
            if (Objects.equals(cursoEscogido, "1º")) {
                asignaturas = getResources().getStringArray(R.array.asignaturas1);
            } else {
                asignaturas = getResources().getStringArray(R.array.asignaturas2);
            }
            ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, asignaturas);
            final Spinner spinner=findViewById(R.id.spinner2);
            spinner.setAdapter(arrayAdapter);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position!=0){
                        String resultado = "Escogida "+ spinner.getItemAtPosition(position).toString()+ " de " +cursoEscogido;
                        Intent intent = new Intent();
                        intent.putExtra("resultado", resultado);
                        setResult(RESULT_OK, intent);
                        finish();
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }
}
