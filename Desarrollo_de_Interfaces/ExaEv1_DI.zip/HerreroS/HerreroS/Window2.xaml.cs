﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HerreroS
{
    /// <summary>
    /// Lógica de interacción para Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {

        public Window2()
        {
            InitializeComponent();
        }

        private void TxtTextoBuscar_TextChanged(object sender, TextChangedEventArgs e)
        {
            var connectionString = ConfigurationManager.ConnectionStrings["miConexion"].ConnectionString;

            string preSql = "SELECT palabra FROM dbo.Diccionario WHERE palabra=";
            string palabra = txtTextoBuscar.Text;
            string sql = preSql + "'" + palabra + "'";

            if (CreateCommand(sql, connectionString))
            {
                lblResultadoBusqueda.Content = "Se ha encontrado la palabra '" + palabra + "'";
            }
            else
            {
                lblResultadoBusqueda.Content = "No se ha encontrado la palabra '" + palabra + "'";
            }
        }

        /// <summary>
        /// Establece la conexión a la base de datos y devuelve true si la consulta devuelve resultados.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="connectionString"></param>
        private bool CreateCommand(string queryString, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                command.Connection.Open();
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    reader.Read();
                    //Si la BD no devuelve registros no se podrá leer el SqlDataReader y lanzará una excepción al intentarlo 
                    try
                    {
                        String resultado = (String)reader[0];
                    }
                    catch (Exception e)
                    {
                        return false;
                    }
                    return true;
                }
            }
        }
    }
}
