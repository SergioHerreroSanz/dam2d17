package examen_Puente;

public class Coche{

    private Puente puente;
    private int nombre;
    private boolean esNorte; /* true NORTE; false SUR */

}
