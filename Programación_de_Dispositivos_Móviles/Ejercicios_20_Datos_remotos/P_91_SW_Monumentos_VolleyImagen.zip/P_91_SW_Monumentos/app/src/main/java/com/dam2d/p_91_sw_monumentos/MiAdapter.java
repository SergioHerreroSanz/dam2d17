package com.dam2d.p_91_sw_monumentos;

import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.dam2d.p_91_sw_monumentos.ItemFragment.OnListFragmentInteractionListener;

import java.util.List;

/**
 * {@link RecyclerView.Adapter} that can display a {@link Item,} and makes a call to the
 * specified {@link OnListFragmentInteractionListener}.
 * TODO: Replace the implementation with code for your data type.
 */
public class MiAdapter extends RecyclerView.Adapter<MiAdapter.ViewHolder> {

    private final List<Item> mValues;

    public MiAdapter(List<Item> items) {
        mValues = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fragment_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, int position) {
        holder.mItem = mValues.get(position);
        holder.imagen.setImageDrawable(mValues.get(position).imagen);
        holder.nombre.setText(mValues.get(position).nombre);
        holder.descripcion.setText(mValues.get(position).direccion);
    }

    @Override
    public int getItemCount() {
        return mValues.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public final View mView;
        public final ImageView imagen;
        public final TextView nombre;
        public final TextView descripcion;
        public Item mItem;

        public ViewHolder(View view) {
            super(view);
            mView = view;
            imagen = (ImageView) view.findViewById(R.id.imageView);
            nombre = (TextView) view.findViewById(R.id.textView_nombre);
            descripcion = (TextView) view.findViewById(R.id.textView_descripcion);
        }

        /*@Override
        public String toString() {
            return super.toString() + " '" + mContentView.getText() + "'";
        }*/
    }
}
