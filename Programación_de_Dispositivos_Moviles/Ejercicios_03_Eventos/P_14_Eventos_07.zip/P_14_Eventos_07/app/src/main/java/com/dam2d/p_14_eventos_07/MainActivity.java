package com.dam2d.p_14_eventos_07;

import androidx.annotation.IdRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void quitarTransparencia(View view){
        ImageView image = findViewById(R.id.imageView);
        int alpha = image.getImageAlpha();
        if (alpha+5 < 255){
            image.setImageAlpha(alpha+5);
        }
    }

    public void ponerTransparencia(View view){
        ImageView image = findViewById(R.id.imageView);
        int alpha = image.getImageAlpha();
        if (alpha-5 > 0){
            image.setImageAlpha(alpha-5);
        }
    }

    public void cambiarColorOriginal(View view){
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        cambiarColor(radioGroup, R.id.radioButton2);
    }
    public void cambiarColorNuevo(View view){
        RadioGroup radioGroup = findViewById(R.id.radioGroup);
        cambiarColor(radioGroup, R.id.radioButton);
    }

    public void cambiarColor(RadioGroup group, @IdRes int i){
        ConstraintLayout fondo = findViewById(R.id.layout_main);
        int color;
        if (i == R.id.radioButton) {
            color = ContextCompat.getColor(getApplicationContext(), R.color.miColor);
        } else {
            color = getResources().getColor(R.color.miColorFondo);
        }
        fondo.setBackgroundColor(color);
    }
}
