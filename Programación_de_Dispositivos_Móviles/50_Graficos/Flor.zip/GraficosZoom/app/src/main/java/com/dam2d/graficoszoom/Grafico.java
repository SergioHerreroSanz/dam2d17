package com.dam2d.graficoszoom;

import android.graphics.Bitmap;

public class Grafico {
    private Bitmap miBitmap;
    private int pos_x;
    private int pos_y;
    private double escala = 1;
    private double maxEscala = 10;
    private boolean creciendo = true;
    private int ancho, alto;
    private MiVista view;

    Grafico(MiVista view, Bitmap miBitmap) {
        this.view = view;
        this.miBitmap = miBitmap;
        ancho = miBitmap.getWidth();
        alto = miBitmap.getHeight();
    }

    Bitmap getMiBitmap() {
        return miBitmap;
    }

    public void setMiBitmap(Bitmap miBitmap) {
        this.miBitmap = miBitmap;
    }

    int getPos_x() {
        return pos_x;
    }

    void setPos_x(int pos_x) {
        this.pos_x = pos_x;
    }

    int getPos_y() {
        return pos_y;
    }

    void setPos_y(int pos_y) {
        this.pos_y = pos_y;
    }

    public double getEscala() {
        return escala;
    }

    public void setEscala(double escala) {
        this.escala = escala;
    }

    public double getMaxEscala() {
        return maxEscala;
    }

    public void setMaxEscala(double maxEscala) {
        this.maxEscala = maxEscala;
    }

    public boolean isCreciendo() {
        return creciendo;
    }

    public void setCreciendo(boolean creciendo) {
        this.creciendo = creciendo;
    }

    int getAncho() {
        return ancho;
    }

    void setAncho(int ancho) {
        this.ancho = ancho;
    }

    int getAlto() {
        return alto;
    }

    void setAlto(int alto) {
        this.alto = alto;
    }

    public MiVista getView() {
        return view;
    }

    public void setView(MiVista view) {
        this.view = view;
    }
}
