package com.dam2d.exa_01_2018_2.dialog;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.dam2d.exa_01_2018_2.R;

public class BDialog extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder
                //Capturar botones
                .setTitle(getString(R.string.CDialog_title))
                .setPositiveButton(R.string.CDialog_positive, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onBDialogPositiveClick();
                    }
                })
                .setNegativeButton(R.string.CDialog_negative, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onBDialogNegativeClick();
                    }
                });
        return builder.create();
    }

    //Interfaz para poder realizar acciones en el main.
    public interface BDialogListener {
        public void onBDialogPositiveClick();

        public void onBDialogNegativeClick();
    }

    BDialogListener miEscuchador;

    //Instanciar el Listener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (BDialogListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement BDialogListener");
        }
    }
}
