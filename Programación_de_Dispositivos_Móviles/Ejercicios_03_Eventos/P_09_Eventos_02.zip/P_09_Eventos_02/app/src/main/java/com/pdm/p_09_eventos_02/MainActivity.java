package com.pdm.p_09_eventos_02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText editText1 = findViewById(R.id.editText);
                EditText editText2 = findViewById(R.id.editText2);
                TextView textView = findViewById(R.id.textView2);
                String valor1 = editText1.getText().toString();
                if(valor1.trim().length()==0){
                    editText1.requestFocus();
                } else {
                    double num1 = Double.parseDouble(valor1);
                    String valor2 = editText2.getText().toString();
                    if (valor2.trim().length() == 0) {
                        editText2.requestFocus();
                    } else {
                        double num2 = Double.parseDouble(valor2);
                        if(num2==0){
                            editText2.requestFocus();
                            textView.setText("No se puede dividir por 0");
                        } else {
                            double division = num1 / num2;
                            String resultado = String.valueOf(division);
                            textView.setText(resultado);
                        }
                    }
                }
            }
        });
    }
}
