package com.dam2d.p_44_fragmentos_05;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RadioGroup;

public class SelectorFragment extends Fragment {
    public SelectorFragment() {
        // Required empty public constructor
    }

    public interface OnCambiosListener {
        void onCambios(int seleccionado);
    }

    OnCambiosListener miListener;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miListener = (OnCambiosListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " falta implementar listener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_selector, container, false);
        RadioGroup radiogroup = view.findViewById(R.id.horizontal);
        radiogroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                miListener.onCambios(checkedId);
            }
        });
        return view;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        miListener = null;
    }
}
