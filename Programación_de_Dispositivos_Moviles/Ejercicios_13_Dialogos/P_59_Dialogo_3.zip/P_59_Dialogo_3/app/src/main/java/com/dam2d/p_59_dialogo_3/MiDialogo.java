package com.dam2d.p_59_dialogo_3;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.widget.DatePicker;

import androidx.fragment.app.DialogFragment;

import java.util.Calendar;

public class MiDialogo extends DialogFragment implements DatePickerDialog.OnDateSetListener {
    public interface MiDialogoListener {
        public void onDateSet(int year, int month, int day);
    }
    MiDialogoListener miEscuchador;

    @Override  public Dialog onCreateDialog(Bundle savedInstanceState) {
        final Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);
        int month = c.get(Calendar.MONTH);
        int day = c.get(Calendar.DAY_OF_MONTH);

        return new DatePickerDialog(getActivity(), this, year, month, day);
    }

    public void onDateSet(DatePicker view, int year, int month, int day) {
        miEscuchador.onDateSet(year, month, day);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiDialogoListener) getActivity();
        } catch(ClassCastException e) {
            throw new ClassCastException(getActivity().toString()  + " must implement MiDialogoListener");
        }
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }
}