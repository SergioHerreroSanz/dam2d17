package com.dam2d.p_77_content_3;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity implements ItemFragment.OnListFragmentInteractionListener {

    public static List<Item> items = new ArrayList<Item>();
    public FragmentManager fragmentManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        ContentResolver cr = Objects.requireNonNull(this).getContentResolver();
        Uri nuestroURI = ConstantesUsar.CONTENT_URI;
        String[] projection = {ConstantesUsar.Column.COL_ID, ConstantesUsar.Column.COL_NOMB, ConstantesUsar.Column.COL_TIPO, ConstantesUsar.Column.COL_CANT};

        Cursor cursor = cr.query(nuestroURI,
                projection,       // Columnas a devolver
                null,             // Condición de la query
                null,             // Argumentos variables de la query
                null); // Orden de los registros
        if ((cursor != null) & (cursor.getCount() != 0)) {
            int i = 0;

            cursor.moveToFirst();
            do {
                //Log.d("qqq", cursor.getString(1));

                Item item = new Item();
                item.setId(cursor.getInt(0));
                item.setNombre(cursor.getString(1));
                item.setTipo(cursor.getString(2));
                item.setCantidad(cursor.getInt(3));
                item.setPos(i);
                i++;

                items.add(item);
            } while (cursor.moveToNext());
        }

        fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().add(R.id.miLayout,new ItemFragment()).commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onListFragmentInteraction(Item item) {
        fragmentManager.beginTransaction().replace(R.id.miLayout,new MostrarFragment(item)).commit();

    }
}
