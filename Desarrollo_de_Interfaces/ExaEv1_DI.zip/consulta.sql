CREATE DATABASE desarrollo
GO

use desarrollo
CREATE TABLE [dbo].[Diccionario](
	idPalabra int NOT NULL IDENTITY(1,1) PRIMARY KEY,
	palabra [varchar](50) NOT NULL
) ON [PRIMARY]
GO

INSERT INTO [dbo].[Diccionario] ([palabra])
	VALUES('dato'),('datos')
GO