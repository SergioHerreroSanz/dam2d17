package com.dam2d.p_24_permisos_peligrosos;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                int hasPermiso = ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE);
                if (hasPermiso == PackageManager.PERMISSION_GRANTED) {
                    llamar();
                } else {
                    pedirPermiso(1);
                }
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void llamar() {
        TextView txt = findViewById(R.id.textView2);
        Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + txt.getText()));

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    private void pedirPermiso(int id) {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, id);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // Si el diálogo ha sido cancelado, el array  está vacío.
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    // Permiso concedido
                    llamar();
                } else {
                    // Permiso rechazado
                    Snackbar.make(findViewById(R.id.activity_main), R.string.permiso, Snackbar.LENGTH_INDEFINITE)
                        .setAction("OK", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                pedirPermiso(1);
                            }
                        }).show()
                    ;
                }
                // otros 'case' para chequear otros posibles permisos que necesita la aplicación
            }
        }
    }
}
