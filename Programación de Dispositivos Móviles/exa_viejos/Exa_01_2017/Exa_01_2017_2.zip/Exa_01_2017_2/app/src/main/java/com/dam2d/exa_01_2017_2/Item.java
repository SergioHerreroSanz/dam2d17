package com.dam2d.exa_01_2017_2;

import android.graphics.drawable.Drawable;

public class Item {
    Drawable imagen;
    String text;
    int id;

    public Item(int id, Drawable imagen, String text) {
        this.imagen = imagen;
        this.text = text;
        this.id = id;
    }

    public Drawable getImagen() {
        return imagen;
    }

    public String getText() {
        return text;
    }

    public int getId() {
        return id;
    }
}
