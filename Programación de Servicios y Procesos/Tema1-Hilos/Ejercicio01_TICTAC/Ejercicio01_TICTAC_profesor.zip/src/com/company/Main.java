package com.company;

public class Main {

    public static void main(String[] args) {
	    // Creo el hilo TIC
        Tictac tic = new Tictac("TIC");
        // Lanzo el hilo de TIC
        tic.start();
        // Creo el hilo TAC
        Tictac tac = new Tictac("TAC");
        // Lanzo el hilo de TAC
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        tac.start();
    }
}
