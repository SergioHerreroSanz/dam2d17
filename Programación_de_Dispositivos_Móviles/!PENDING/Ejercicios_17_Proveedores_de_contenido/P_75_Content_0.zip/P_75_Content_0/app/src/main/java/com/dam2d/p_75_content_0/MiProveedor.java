package com.dam2d.p_75_content_0;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class MiProveedor extends ContentProvider {
    public MiProveedor() {
    }

    @Override
    public boolean onCreate() {
        SQLiteDatabase db = getSqLiteDatabase();
        if (db == null) {
            return false;
        }
        if (db.isReadOnly()) {
            db.close();
            return false;
        }
        db.close();
        return true;
    }

    //region Métodos propios
    private SQLiteDatabase getSqLiteDatabase() {
        MiAdminSqlite admin = MiAdminSqlite.getInstance(getContext(), Constantes.BD_NOMBRE, null, Constantes.BD_VERSION);
        return admin.getWritableDatabase();
    }

    @Nullable
    private String getString(@NonNull Uri uri, String selection) {
        String where = null;
        switch (Constantes.uriMatcher.match(uri)) {
            case Constantes.TODOS:
                where = selection;
                break;
            case Constantes.UNO:
                where = " _id = " + uri.getLastPathSegment();
                break;
        }
        return where;
    }

    @Override
    public String getType(@NonNull Uri uri) {
        int match = Constantes.uriMatcher.match(uri);
        switch (match) {
            case Constantes.TODOS:
                return Constantes.MIME_MULTIPLE;
            case Constantes.UNO:
                return Constantes.MIME_SIMPLE;
            default:
                return null;
        }
    }

    //endregion
    //region Acciones BD
    @Override
    public Uri insert(@NonNull Uri uri, ContentValues values) {
        SQLiteDatabase db = getSqLiteDatabase();
        long regId = db.insert(Constantes.TABLA, null, values);
        return ContentUris.withAppendedId(Constantes.CONTENT_URI, regId);
    }

    @Override
    public Cursor query(@NonNull Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        SQLiteDatabase db = getSqLiteDatabase();
        String where = null;
        switch (Constantes.uriMatcher.match(uri)) {
            case Constantes.TODOS:
                where = selection;
                break;
            case Constantes.UNO:
                where = " _id = " + uri.getLastPathSegment();
                break;
        }
        return db.query(Constantes.TABLA, projection, where, selectionArgs, null, null, sortOrder);
    }

    @Override
    public int update(@NonNull Uri uri, ContentValues values, String selection,
                      String[] selectionArgs) {
        SQLiteDatabase db = getSqLiteDatabase();
        String where = null;
        switch (Constantes.uriMatcher.match(uri)) {
            case Constantes.TODOS:
                where = selection;
                break;
            case Constantes.UNO:
                where = " _id = " + uri.getLastPathSegment();
                break;
        }
        return db.update(Constantes.TABLA, values, where, selectionArgs);
    }

    @Override
    public int delete(@NonNull Uri uri, String selection, String[] selectionArgs) {
        int cont;
        try (SQLiteDatabase db = getSqLiteDatabase()) {
            String where = getString(uri, selection);
            cont = db.delete(Constantes.TABLA, where, selectionArgs);
        }
        return cont;
    }
    //endregion
}
