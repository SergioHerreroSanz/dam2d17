package com.dam2d.p_62_nav_02;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class MiDialogo extends DialogFragment {
    public interface MiDialogoListener {
        public void onDialogPositiveClick();
        public void onDialogNegativeClick();
    }

    MiDialogoListener miEscuchador;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        //Capturar botones
        builder.setTitle("Cambiar imagen")
                .setMessage("¿Qué imagen quieres ver?")
                .setPositiveButton("Moderna", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onDialogPositiveClick();
                    }
                })
                .setNegativeButton("Antigua", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onDialogNegativeClick();
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiDialogoListener) getActivity();
        } catch(ClassCastException e) {
            throw new ClassCastException(getActivity().toString()  + " must implement MiDialogoListener");
        }
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }
}
