package com.dam2d.p_45_tabs;

import android.content.Context;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import static com.dam2d.p_45_tabs.BlankFragment.*;
import static com.dam2d.p_45_tabs.BlankFragment.*;

public class MiFragmentPagerAdapter extends FragmentPagerAdapter {
    private final String[] textosTab;
    private Context context;

    public MiFragmentPagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        textosTab = context.getResources().getStringArray(R.array.opciones);
        this.context = context;
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        switch (position) {
            case 0:
                fragment = BlankFragment.newInstance(textosTab[position], position);
                break;
            case 1:
                fragment = new BlankFragment2(textosTab[position], position, context);
                break;
            case 2:
                fragment = BlankFragment.newInstance(textosTab[position], position);
                break;
        }
        return fragment;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return textosTab[position];
    }

}