package com.dam2d.P_26_Creciente_03;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private boolean mostrarDespedida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mostrarDespedida = false;
        Button btn3 = findViewById(R.id.button3);
        Button btn4 = findViewById(R.id.button4);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.button3:
                Intent intent = new Intent(getApplicationContext(), SegundaActivity.class);
                startActivity(intent);
                break;
            case R.id.button4:
                mostrarDespedida = true;
                finish();
                break;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mostrarDespedida) {
            Toast.makeText(getApplicationContext(), "Hasta la próxima", Toast.LENGTH_LONG).show();
        }
    }
}
