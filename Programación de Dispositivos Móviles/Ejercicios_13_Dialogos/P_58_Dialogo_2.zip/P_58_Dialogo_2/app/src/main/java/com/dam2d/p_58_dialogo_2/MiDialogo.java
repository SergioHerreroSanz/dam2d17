package com.dam2d.p_58_dialogo_2;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class MiDialogo extends DialogFragment {
    String nombre;
    String[] asignaturas = {"BD", "ED", "PDM"};

    public MiDialogo(String nombre) {
        this.nombre = nombre;
    }

    public interface MiDialogoListener {
        public void onItemSelected(String seleccionado);
    }
    MiDialogoListener miEscuchador;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle(nombre+" escoja materia")
            .setItems(asignaturas, new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int posicion) {
                    miEscuchador.onItemSelected(asignaturas[posicion]);
                }
            });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiDialogoListener) getActivity();
        } catch(ClassCastException e) {
            throw new ClassCastException(getActivity().toString()  + " must implement MiDialogoListener");
        }
    }

    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }
}