package com.pdm.boned02;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class MiAdaptador extends RecyclerView.Adapter<MiAdaptador.MiViewHolder> {

    public ArrayList<Item>datos;
    private final Context context;
    int id,bonos;
    String socio;
    private VerFragment.OnSocio mListener;

    public MiAdaptador(ArrayList<Item> datos, Context context, VerFragment.OnSocio mListener){
        this.datos=datos;
        this.context=context;
        this.mListener=mListener;
    }


    @NonNull
    @Override
    public MiViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_item,parent,false);
        return new MiViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MiViewHolder holder, int position) {
        socio=datos.get(position).getNombre();
        id=datos.get(position).getId();
        bonos=datos.get(position).getBonos();
        holder.txtid.setText(String.valueOf(id));
        holder.txtsocio.setText(socio);
        holder.txtbonos.setText(String.valueOf(bonos));
    }

    @Override
    public int getItemCount() {
        return datos.size();
    }

    class MiViewHolder extends RecyclerView.ViewHolder{
        TextView txtid,txtsocio,txtbonos;
         public MiViewHolder(@NonNull View itemView) {
             super(itemView);
             txtid=itemView.findViewById(R.id.textId);
             txtsocio=itemView.findViewById(R.id.textSocio);
             txtbonos=itemView.findViewById(R.id.textBonos);
             itemView.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                     mListener.onSocioClick(Integer.parseInt(txtid.getText().toString()),txtsocio.getText().toString(),Integer.parseInt(txtbonos.getText().toString()));
                 }
             });
         }
     }
}
