package com.pdm.exa_1_2019_bis;

import android.graphics.drawable.Drawable;

class Item {
    private String texto;
    private Drawable imagen;

    Item(String texto, Drawable imagen) {
        this.texto = texto;
        this.imagen = imagen;
    }

    Drawable getImagen() { return imagen; }

    String getTexto() {
        return texto;
    }
}
