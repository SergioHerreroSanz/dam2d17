﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary>
    /// Lógica de interacción para SelectorColor.xaml
    /// </summary>
    public partial class SelectorColor : Window
    {
        public SelectorColor()
        {
            InitializeComponent();
        }

        private void Button_Click_Cancelar(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void Button_Click_Aceptar(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !IsValid(((TextBox)sender).Text + e.Text);
        }
        public static bool IsValid(string str)
        {
            int val;
            return int.TryParse(str, out val) && val >= 0 && val <= 255;
        }

        private void TxtBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            textBox.Dispatcher.BeginInvoke(new Action(() => textBox.SelectAll()));
        }

        private void Scb_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            byte rojo = (byte)scbRojo.Value;
            byte verde = (byte)scbVerde.Value;
            byte azul = (byte)scbAzul.Value;

            txtRojo.Text = rojo.ToString();
            txtVerde.Text = verde.ToString();
            txtAzul.Text = azul.ToString();

            display.Fill = new SolidColorBrush(Color.FromRgb(rojo, verde, azul));
        }

        private void Txt_TextChanged(object sender, RoutedEventArgs e)
        {
            try
            {
                byte rojo = byte.Parse(txtRojo.Text);
                byte verde = byte.Parse(txtVerde.Text);
                byte azul = byte.Parse(txtAzul.Text);
                display.Fill = new SolidColorBrush(Color.FromRgb(rojo, verde, azul));
                scbRojo.Value = rojo;
                scbVerde.Value = verde;
                scbAzul.Value = azul;
            }
            catch (Exception ex) { Console.WriteLine(ex); }
        }
    }
}
