package com.pdm.exa_1_2019_bis;

import android.content.Intent;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import java.util.Objects;

public class DetalleActivity extends AppCompatActivity implements FijoFragment.MiListenerFijo, MovilFragment.MiListenerMovil{

    private Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            finish();
            return;
        }
        setContentView(R.layout.activity_detalle);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        int seleccionado = Objects.requireNonNull(bundle).getInt("seleccionado");
        switch (seleccionado) {
            case 0:
                fragment = new FijoFragment();
                break;
            case 1:
                fragment = new MovilFragment();
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle, fragment).commit();
    }

    @Override
    public void onFijoTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:976444444"));
        startActivity(intent);
    }

    @Override
    public void onMovilTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:666666666"));
        startActivity(intent);
    }

}
