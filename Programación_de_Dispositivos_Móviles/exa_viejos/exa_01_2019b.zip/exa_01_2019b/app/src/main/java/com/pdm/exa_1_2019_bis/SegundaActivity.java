package com.pdm.exa_1_2019_bis;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

public class SegundaActivity extends AppCompatActivity implements SeguirFragment.MiListener, FijoFragment.MiListenerFijo,MovilFragment.MiListenerMovil{

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_fijo, R.id.nav_movil, R.id.nav_seguir)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);
    }


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public void onClickTocado() {
        Intent intent=new Intent(getApplicationContext(),TerceraActivity.class);
        startActivity(intent);
    }

    @Override
    public void onFijoTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:976444444"));
        startActivity(intent);
    }

    @Override
    public void onMovilTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:666666666"));
        startActivity(intent);
    }
}
