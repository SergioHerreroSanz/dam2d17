package com.dam2d.graficoszoom;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

public class HiloPintor extends Thread {
    private final MiVista miVista;
    private final SurfaceHolder holder;
    boolean debeEjecutarse;

    public HiloPintor(SurfaceHolder holder, MiVista miVista) {
        this.miVista = miVista;
        this.holder = holder;
        debeEjecutarse = true;
    }

    @Override
    public void run() {
        super.run();
        while (debeEjecutarse) {
            long antesDePintar = System.nanoTime();
            Canvas canvas = null;
            try {
                canvas = holder.lockCanvas(null);
                synchronized (holder) {
                    miVista.pintar(canvas);
                }
            } finally {
                if (canvas != null) {
                    holder.unlockCanvasAndPost(canvas);
                }
            }
            long despuesDePintar = System.nanoTime();
            long retrasoVisual = 50;
            long tiempoDescanso = retrasoVisual - ((despuesDePintar - antesDePintar) / 1000000L);
            try {
                if (tiempoDescanso > 0) {
                    //sleep(tiempoDescanso);
                    sleep(0);
                }
            } catch (InterruptedException ignored) {
            }
        }
    }
}
