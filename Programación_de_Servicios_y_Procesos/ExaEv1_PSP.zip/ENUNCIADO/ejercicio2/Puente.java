package examen_Puente;

public class Puente {

    private int nCochesNorte = 0;
    private int nCochesSur = 0;

    /* metodo al que llamaran los coches que quieren cruzar del norte */
    public void entraCocheNorte(int nombre){

    }

    /* metodo al que llamaran los coches que quieren cruzar del sur */
    public void entraCocheSur(int nombre){

    }

    /* metodo para salir del puente, tanto si eres norte como sur */
    public void salirPuente(int nombre){

    }
}
