﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp6
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var connectionString = ConfigurationManager.ConnectionStrings["WingtipToys"].ConnectionString;      //Obtenemos la cadena de conexión de App.config
            string query = "select * from dbo.Formularios";                                                     //Creamos la sentencia SQL

            txt.Content = CreateCommand(query, connectionString);                                               //Ejecutamos el método de la conexión
        }

        /// <summary>
        /// Establece la conexión a la base de datos y devuelve el valor de la segunda columna de la primera fila.
        /// </summary>
        /// <param name="queryString"></param>
        /// <param name="connectionString"></param>
        private String CreateCommand(string queryString, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);           //Creamos la conexión
                command.Connection.Open();                                              //Abrimos la conexión
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    reader.Read();                                                      //En cada iteración leemos una línea (solo hay una) y la almacenamos en reader[]
                    return (String)reader[1];                                           //Devolvemos el valor de reader[]
                }
            }
        }

        private void BtnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
