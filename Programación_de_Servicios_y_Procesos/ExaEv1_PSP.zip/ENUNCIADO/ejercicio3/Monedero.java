package monedero;

public class Monedero {

    private int cantidad;

    public Monedero(int cantidad) {
        this.cantidad = cantidad;
    }

    public synchronized int sacarDinero(int dineroAsacar) throws InterruptedException {
        if (cantidad >= dineroAsacar){
            cantidad -= dineroAsacar;
            return dineroAsacar;
        } else {
            return 0;
        }
    }

}
