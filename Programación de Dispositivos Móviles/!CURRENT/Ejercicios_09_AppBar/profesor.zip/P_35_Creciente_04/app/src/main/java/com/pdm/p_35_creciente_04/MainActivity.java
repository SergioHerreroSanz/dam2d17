package com.pdm.p_35_creciente_04;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private boolean pulsadoBoton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        Button button_acerca=findViewById(R.id.button3);
        button_acerca.setOnClickListener(this);
        Button button_salir=findViewById(R.id.button4);
        button_salir.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.info:
                Intent intent=new Intent(getApplicationContext(),SegundaActivity.class);
                startActivity(intent);
                break;
            case R.id.config:
                Toast.makeText(getApplicationContext(), getResources().getString(R.string.texto7),Toast.LENGTH_LONG).show();
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.button3:
                Intent intent=new Intent(getApplicationContext(), SegundaActivity.class);
                startActivity(intent);
                break;
            case R.id.button4:
                pulsadoBoton=true;
                finish();
        }
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pulsadoBoton) {
            Toast.makeText(this, "Hasta pronto!", Toast.LENGTH_SHORT).show();
        }
    }
}
