package com.dam2d.p_13_eventos_06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private double valorDolares = 1.1;
    private double valorEuros = 1/valorDolares;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void close(View view) {
        finish();
    }

    public void convertirDolares(View view) {
        EditText editText1 = findViewById(R.id.editText);
        EditText editText2 = findViewById(R.id.editText2);
        convertir(editText2, editText1, valorDolares);
    }

    public void convertirEuros(View view) {
        EditText editText1 = findViewById(R.id.editText);
        EditText editText2 = findViewById(R.id.editText2);
        convertir(editText1, editText2, valorEuros);
    }

    public void convertir(EditText editText1, EditText editText2, Double valor) {
        String valor1 = editText1.getText().toString();
        if (valor1.trim().length() == 0) {
            editText1.requestFocus();
        } else {
            double num1 = Double.parseDouble(valor1);
            String valor2 = editText2.getText().toString();
            double dolares = num1 * valor;
            String resultado = String.valueOf(dolares);
            editText2.setText(resultado);
        }
    }
}
