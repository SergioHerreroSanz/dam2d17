package com.dam2d.exa_01_2018_2.ui;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.dam2d.exa_01_2018_2.R;

import static android.content.Context.MODE_PRIVATE;


/**
 * A simple {@link Fragment} subclass.
 */
public class AFragment extends Fragment {


    public AFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        SharedPreferences prefe = getActivity().getPreferences(MODE_PRIVATE);
        boolean primeraVez = prefe.getBoolean("firstTime", true);
        if (!primeraVez) {
            TextView textView = view.findViewById(R.id.textView2);
            String textoPreferencia = prefe.getString("text", "");
            String texto = getString(R.string.a_TextView2_text2, textoPreferencia);
            textView.setText(texto);
        }

        Button button = view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miEscuchador.onAGuardar();
            }
        });

        // Inflate the layout for this fragment
        return view;
    }

    public interface AListener {
        public void onAGuardar();
    }

    AListener miEscuchador;

    //Instanciar el Listener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (AListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement SAListener");
        }
    }

    //Acciones a realizar cuando se sale sin realizar acciones
    @Override
    public void onDetach() {
        super.onDetach();
        miEscuchador = null;
    }
}
