package com.pdm.exa_1_2019_bis;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Objects;


public class FijoFragment extends Fragment {

    public interface MiListenerFijo {
        void onFijoTocado();
    }

    private MiListenerFijo miEscuchador;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiListenerFijo) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(Objects.requireNonNull(getActivity()).toString()
                    + " must implement FijoListener");
        }
    }
    public FijoFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_fijo, container, false);
        ImageView imageView=view.findViewById(R.id.imageView2);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miEscuchador.onFijoTocado();
            }
        });
        return view;
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }
}
