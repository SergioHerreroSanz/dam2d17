package com.dam2d.p_62_nav_02;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;


/**
 * A simple {@link Fragment} subclass.
 */
public class ZaragozaFragment extends Fragment {


    public ZaragozaFragment() {
        // Required empty public constructor
    }

    public interface MiFragmentListener {
        public void onButtonZaragozaClick();
    }
    MiFragmentListener miEscuchadorZaragoza;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_zaragoza, container, false);
        // Inflate the layout for this fragment

        Button button = view.findViewById(R.id.button_zaragoza);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("debug", "Funciona desde el ZaragozaFragment");
                miEscuchadorZaragoza.onButtonZaragozaClick();
                Log.d("debug", "Funciona desde el ZaragozaFragment despues");
            }
        });
        return view;
    }
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchadorZaragoza = (ZaragozaFragment.MiFragmentListener) getActivity();
        } catch(ClassCastException e) {
            throw new ClassCastException(getActivity().toString()  + " must implement MiFragmentListener");
        }
    }
}
