package com.pdm.p_32_spinner_personalizado_02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Accedemos a los arrays de string y drawable
        final Resources resources = getResources();
        final String[] version = resources.getStringArray(R.array.version);
        final String[] num_api = resources.getStringArray(R.array.num_api);
        TypedArray logos = resources.obtainTypedArray(R.array.logos);
        /*
         * Construimos la lista de nuestro adapter asociando cada item
         * con su número de api y su imagen
         */
        ArrayList<Item> lista = new ArrayList<>();
        for (int i = 0; i < 7; i++) {
            lista.add(new Item(i + 1, version[i], logos.getDrawable(i)));
        }
        logos.recycle();
        MiAdaptador miAdaptador = new MiAdaptador(this, lista);
        Spinner spinner = findViewById(R.id.spinner);
        spinner.setAdapter(miAdaptador);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position!=0) {
                    String resu = version[position] + " es " + num_api[position];
                    Toast.makeText(getApplicationContext(), resu, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
