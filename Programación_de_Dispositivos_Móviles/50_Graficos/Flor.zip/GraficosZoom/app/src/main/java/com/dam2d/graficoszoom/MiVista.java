package com.dam2d.graficoszoom;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;

/**
 * TODO: document your custom view class.
 */
public class MiVista extends SurfaceView implements SurfaceHolder.Callback {
    SurfaceHolder holder;
    HiloPintor hiloPintor;
    private int anchoVista, altoVista;
    private TypedArray imagenes;
    private Grafico[] graficos;
    Double velocidad = 0.25;

    public MiVista(Context context) {
        super(context);
        holder = getHolder();
        holder.addCallback(this);

        imagenes = getResources().obtainTypedArray(R.array.imagenes);
        graficos = new Grafico[imagenes.length()];

        for (int i = 0; i < imagenes.length(); i++) {
            Drawable drawable = imagenes.getDrawable(i);
            Bitmap bitmap = ((BitmapDrawable) drawable).getBitmap();
            //Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.ball);
            graficos[i] = new Grafico(this, bitmap);
            graficos[i].setPos_x(bitmap.getWidth());
            graficos[i].setPos_y(bitmap.getHeight());
            graficos[i].setAlto(bitmap.getHeight());
            graficos[i].setAncho(bitmap.getWidth());
        }

        anchoVista = getWidth();
        altoVista = getHeight();
    }

    public void pintar(Canvas canvas) {
        canvas.drawColor(Color.GREEN);
        for (int i = 0; i < graficos.length; i++) {
            int ancho = graficos[i].getAncho();
            int alto = graficos[i].getAlto();
            int pos_x = graficos[i].getPos_x();
            int pos_y = graficos[i].getPos_y();
            double escala = graficos[i].getEscala();
            boolean creciendo = graficos[i].isCreciendo();
            Bitmap bitmap = graficos[i].getMiBitmap();

            //modificamos la escala
            if (creciendo) {
                graficos[i].setEscala(escala + 0.1);
            } else {
                graficos[i].setEscala(escala - 0.1);
            }

            //cambiamos la direccion de crecimiento si toca un borde
            if ((pos_x + (ancho / 2) > anchoVista) || (pos_x - (ancho / 2) < 0) || (pos_y + (alto / 2) > altoVista) || (pos_y - (ancho / 2) < 0)) {
                graficos[i].setCreciendo(false);
            } else if (escala < 1) {
                graficos[i].setCreciendo(true);
            }

            //averiguamos y guardamos la posición
            pos_x = (int) (500 - (ancho / 2) * escala);
            pos_y = (int) (500 - (alto / 2) * escala);
            graficos[i].setPos_x(pos_x);
            graficos[i].setPos_y(pos_y);

            //escalamos el bitmap
            bitmap = Bitmap.createScaledBitmap(bitmap, (int) (bitmap.getWidth() * escala), (int) (bitmap.getHeight() * escala), true);

            // pintamos cada imagen en su posicion
            canvas.drawBitmap(bitmap, pos_x, pos_y, null);
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        hiloPintor = new HiloPintor(holder, this);
        hiloPintor.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
        anchoVista = width;
        altoVista = height;
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        try {
            hiloPintor.debeEjecutarse = false;
            hiloPintor.join();
        } catch (InterruptedException ignored) {
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
    }
}
