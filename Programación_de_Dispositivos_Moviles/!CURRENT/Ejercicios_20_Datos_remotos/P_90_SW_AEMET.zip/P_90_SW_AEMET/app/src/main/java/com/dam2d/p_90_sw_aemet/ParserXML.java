package com.dam2d.p_90_sw_aemet;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.util.ArrayList;

class ParserXML {
    ArrayList<Dia> parsear(InputStream inputStream) {
        ArrayList<Dia> datos = null;
        XmlPullParser parser = Xml.newPullParser();
        try {
            String etiqueta;
            Dia dia = null;
            parser.setInput(inputStream, null);


            int tipoEncontrado = parser.getEventType();
            boolean temperatura = false;
            while (tipoEncontrado != XmlPullParser.END_DOCUMENT) {


                switch (tipoEncontrado) {
                    case XmlPullParser.START_DOCUMENT:
                        datos = new ArrayList<Dia>();
                        break;

                    case XmlPullParser.START_TAG:
                        etiqueta = parser.getName();
                        if (etiqueta.equals("dia")) {
                            dia = new Dia();
                            dia.setFecha(parser.getAttributeValue(0));
                        }
                        if (etiqueta.equals("temperatura")) {
                            temperatura = true;
                        }
                        if (etiqueta.equals("maxima")) {
                            if ((dia != null) & temperatura) {
                                dia.setTempMax(parser.nextText());
                            }
                        }
                        if (etiqueta.equals("minima")) {
                            if ((dia != null) & temperatura) {
                                dia.setTempMin(parser.nextText());
                            }
                        }
                        break;

                    case XmlPullParser.END_TAG:
                        etiqueta = parser.getName();

                        if (etiqueta.equals("dia")) {
                            if (datos != null) {
                                datos.add(dia);
                                dia = null;
                            }
                        }
                        if (etiqueta.equals("temperatura")) {
                            temperatura = false;
                        }
                        break;
                }
                tipoEncontrado = parser.next();
            }
        } catch (
                Exception ex) {
            throw new RuntimeException(ex);
        }
        return datos;
    }
}