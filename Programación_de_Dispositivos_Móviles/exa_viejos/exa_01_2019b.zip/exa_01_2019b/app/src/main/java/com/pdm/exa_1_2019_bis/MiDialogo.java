package com.pdm.exa_1_2019_bis;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import java.util.Objects;

public class MiDialogo extends DialogFragment {

    public interface MiDialogoListener {
        void onSeguir();
        void onAcabar();
        void onCancelar();
    }

    private MiDialogoListener miEscuchador;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiDialogoListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(Objects.requireNonNull(getActivity()).toString()
                    + " must implement MiDialogoListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(Objects.requireNonNull(getActivity()));
        builder.setTitle(getResources().getString(R.string.escoja))
                .setPositiveButton(R.string.seguir,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                miEscuchador.onSeguir();
                            }
                        })
                .setNegativeButton(R.string.acabar,
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                miEscuchador.onAcabar();
                            }
                        })    ;
        return builder.create();
    }

    @Override
    public void onDetach() {
        super.onDetach();
        miEscuchador = null;
    }

    @Override
    public void onCancel(DialogInterface dialog) {
        miEscuchador.onCancelar();
    }

}
