package com.dam2d.p_44_fragmentos_05;


import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.Switch;


/**
 * A simple {@link Fragment} subclass.
 */
public class DinamicoFragment extends Fragment {


    public DinamicoFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dinamico, container, false);
        final Switch aSwitch = view.findViewById(R.id.switch1);
        final FrameLayout frameLayout = view.findViewById(R.id.dinamicoLayout);
        aSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (aSwitch.isChecked())
                    frameLayout.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorPrimary));
                else
                    frameLayout.setBackgroundColor(ContextCompat.getColor(getActivity(), R.color.colorAccent));
            }
        });
        return view;
    }

    public interface OnSwitchTocadoListener {
        void onSwitchTocado(boolean valor);
    }
}
