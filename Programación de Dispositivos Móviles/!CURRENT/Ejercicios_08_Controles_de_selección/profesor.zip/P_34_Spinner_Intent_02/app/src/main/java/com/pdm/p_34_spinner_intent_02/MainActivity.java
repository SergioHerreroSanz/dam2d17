package com.pdm.p_34_spinner_intent_02;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.textView);
        String[] cursos =getResources().getStringArray(R.array.cursos);
        ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, cursos);
        spinner=findViewById(R.id.spinner);
        spinner.setAdapter(arrayAdapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position!=0){
                    Intent intent=new Intent(getApplicationContext(),SegundaActivity.class);
                    intent.putExtra("cursoEscogido",spinner.getItemAtPosition(position).toString());
                    startActivityForResult(intent,123);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    protected void onActivityResult(int requestCode,int resultCode, Intent intent)
    {
        String res="Sin resolver";
        if(requestCode==123 && resultCode==RESULT_OK && intent.getExtras()!=null){
            res=intent.getExtras().getString("resultado");
        }
        spinner.setVisibility(View.INVISIBLE);
        textView.setText(res);
    }
}
