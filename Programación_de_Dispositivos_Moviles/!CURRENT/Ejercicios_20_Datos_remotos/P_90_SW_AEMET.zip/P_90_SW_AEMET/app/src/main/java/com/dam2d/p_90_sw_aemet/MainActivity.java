package com.dam2d.p_90_sw_aemet;


import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    public static String direccion = "http://www.aemet.es/xml/municipios/localidad_50297.xml";
    static RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        recyclerView = findViewById(R.id.recyclerView);

        try {
            ArrayList<Dia> dias = new DescargaDatos().execute(direccion).get();
            for (Dia dia : dias) {
                Log.d("qqq", "[" + dia.getFecha() + "] Max: " + dia.getTempMax() + " Min: " + dia.getTempMin());
            }
            RecyclerView recyclerView = findViewById(R.id.recyclerView);
            recyclerView.setHasFixedSize(true);
            RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
            recyclerView.setLayoutManager(layoutmanager);
            MyDiaRecyclerViewAdapter miAdaptador = new MyDiaRecyclerViewAdapter(dias, null);
            recyclerView.setAdapter(miAdaptador);
        } catch (
                ExecutionException e) {
            e.printStackTrace();
        } catch (
                InterruptedException e) {
            e.printStackTrace();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
}

class DescargaDatos extends AsyncTask<String, Void, ArrayList<Dia>> {

    static ArrayList<Dia> datos = null;

    @Override
    protected ArrayList<Dia> doInBackground(String... urlString) {
        try {
            URL url = new URL(urlString[0]);
            HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
            conexion.setReadTimeout(10000);
            conexion.setConnectTimeout(15000);
            conexion.setRequestMethod("GET");

            conexion.connect();//TODO: Rompe aquí

            InputStream stream = conexion.getInputStream();
            // PARSEO DEL CONTENIDO DESCARGADO
            datos = new ParserXML().parsear(stream);
            stream.close();
            conexion.disconnect();
        } catch (IOException ignored) {
            ignored.printStackTrace();
        }
        return datos;
    }


    /*@Override
    protected void onPostExecute(ArrayList<Dia> datos) {
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(layoutmanager);
        MyDiaRecyclerViewAdapter miAdaptador = new MyDiaRecyclerViewAdapter(datos, null);
        recyclerView.setAdapter(miAdaptador);
    }*/
}
