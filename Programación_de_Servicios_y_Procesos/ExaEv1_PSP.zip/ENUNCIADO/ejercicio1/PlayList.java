package examen_DJ;

import java.util.LinkedList;

public class PlayList {

    private LinkedList<String> playList = new LinkedList<String>();
    private boolean estoyOcupado = false;

    /*Este metodo añade la cancion al final de la playlist*/
    public synchronized void  addSong (String cancion){
        playList.add(cancion);
    }

    /*Este metodo devuelve la cancion que esta sonando*/
    public synchronized String currentSong(){
        return playList.getFirst();
    }

    /*Este metodo devuelve la siguiente cancion que sonara*/
    public synchronized String nextSong(){
        return playList.get(1);
    }

    /*Este metodo no permite que las nuevas peticiones se añadan a la playList*/
    public synchronized void djModoON(){

    }

    /*Este metodo permite que las nuevas peticiones se añadan a la playList*/
    public synchronized void djModoOFF(){

    }

}
