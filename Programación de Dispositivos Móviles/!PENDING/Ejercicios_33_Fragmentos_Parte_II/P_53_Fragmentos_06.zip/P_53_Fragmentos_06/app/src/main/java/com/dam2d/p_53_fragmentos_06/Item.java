package com.dam2d.p_53_fragmentos_06;

public class Item {
    String texto;

    public Item(String texto) {
        this.texto = texto;
    }

    public String getTexto() {
        return texto;
    }
}