package com.dam2d.p_77_content_3;

import android.net.Uri;
import android.provider.BaseColumns;

class ConstantesUsar {
    //Autoridad del Content Provider
    private final static String AUTHORITY = "com.dam2d.p_75_content_0";
    // Representación de la tabla a consultar
    private static final String TABLA = "platos";
    // URI de contenido principal
    static final String stringUri = "content://" + AUTHORITY + "/" + TABLA;
    static final Uri CONTENT_URI = Uri.parse(stringUri);
    // Estructura de la tabla
    static class Column implements BaseColumns {
        private Column() {
            // Sin instancias
        }
        //Nombres de columnas
        static final String COL_ID = "_id";
        static final String COL_NOMB = "nombre";
        static final String COL_TIPO = "tipo";
        static final String COL_CANT = "cantidad";
    }
}
