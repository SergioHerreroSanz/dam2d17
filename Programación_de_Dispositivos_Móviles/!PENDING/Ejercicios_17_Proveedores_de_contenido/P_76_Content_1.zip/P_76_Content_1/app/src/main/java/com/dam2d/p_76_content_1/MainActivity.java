package com.dam2d.p_76_content_1;

import android.content.ContentResolver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    Cursor cursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        final EditText editText = findViewById(R.id.editText);
        Button button = findViewById(R.id.button);

        ContentResolver cr = Objects.requireNonNull(this).getContentResolver();

        Uri nuestroURI = ConstantesUsar.CONTENT_URI;


        String[] projection = {ConstantesUsar.Column.COL_CANT};
        //Hacemos la consulta
        cursor = cr.query(nuestroURI,
                projection,       // Columnas a devolver
                null,             // Condición de la query
                null,             // Argumentos variables de la query
                null); // Orden de los registros
        if (cursor != null) {
            if (cursor.getCount() != 0) {
                editText.setVisibility(View.VISIBLE);
                button.setVisibility(View.VISIBLE);
                Log.d("qqq", "" + cursor.getCount());
                final Cursor c = cursor;
                Log.d("qqq", "" + c.getCount());

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String msg;
                        int pocosPlatos = 0;

                        String num;
                        if (!(num = String.valueOf(editText.getText())).equals("")) {
                            int cantidadDeseada = Integer.parseInt(num);

                            c.moveToFirst();
                            do {
                                if (Integer.parseInt(c.getString(0)) <= cantidadDeseada) {
                                    pocosPlatos++;
                                }
                            } while (c.moveToNext());

                            if (pocosPlatos == 0) {
                                msg = "Hay de todo";
                            } else {
                                msg = "Hay " + pocosPlatos + " platos con menos de " + cantidadDeseada + " raciones.";
                            }

                            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(MainActivity.this, "Introduzca un valor válido", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            } else {
                Toast.makeText(this, "BD vacía", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "BD no creada", Toast.LENGTH_SHORT).show();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
