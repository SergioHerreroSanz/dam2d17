﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace Acceso_Datos
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string connectionString;
        public MainWindow()
        {
            InitializeComponent();
            connectionString = ConfigurationManager.ConnectionStrings["cadenaConexion"].ConnectionString;
        }

        /// <summary>
        /// Manejador de evento que recuperará datos usando la clase SqlDataReader 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnConexion_Click(object sender, RoutedEventArgs e)
        {
            SqlDataReader datos = null;
            try
            {
                SqlConnection conexion = new SqlConnection(connectionString);
                conexion.Open();

                SqlCommand cmd = new SqlCommand("select * from MSreplication_options", conexion);

                datos = cmd.ExecuteReader();

                // Call Read before accessing data.
                while (datos.Read())
                {
                    ReadSingleRow((IDataRecord)datos);
                }

                datos.Close();
                conexion.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>
        /// Método que pinta la info del SqlDataReader
        /// </summary>
        /// <param name="record"></param>
        private static void ReadSingleRow(IDataRecord record)
        {
            Console.WriteLine(String.Format("{0}, {1}", record[0], record[1]));
        }

        /// <summary>
        /// Método que accederá a db pasará los datos a un data adapter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDataAdapter_Click(object sender, RoutedEventArgs e)
        {
            DataSet datos = new DataSet();
            string query = "select * from MSreplication_options";
            SelectRows(datos, connectionString, query);

            DataTable dt = datos.Tables[0];
            foreach (DataRow row in dt.Rows)
            {
                string valor1 = Convert.ToString(row[0]);
                string valor2 = Convert.ToString(row[1]);
                string valor3 = Convert.ToString(row[2]);
                string valor4 = Convert.ToString(row[3]);
                string valor5 = Convert.ToString(row[4]);
                string valor6 = Convert.ToString(row[5]);
                Console.WriteLine(valor1);
                Console.WriteLine(valor2);
                Console.WriteLine(valor3);
                Console.WriteLine(valor4);
                Console.WriteLine(valor5);
                Console.WriteLine(valor6);
                Console.WriteLine("");
            }
        }

        /// <summary>
        /// Método que rellena devuelve un DataSet con los datos obtenidos desde el objeto SqlDataAdapter
        /// </summary>
        /// <param name="dataset"></param>
        /// <param name="connectionString"></param>
        /// <param name="queryString"></param>
        /// <returns></returns>
        private static DataSet SelectRows(DataSet dataset, string connectionString, string queryString)
        {
            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(
                    queryString, connection);
                adapter.Fill(dataset);

                // Acceso a los datos de la tabla dentro del dataset a través de la inspección rápida
                //dataset.Tables[0].Rows[0].ItemArray
                return dataset;
            }
        }
    }
}
