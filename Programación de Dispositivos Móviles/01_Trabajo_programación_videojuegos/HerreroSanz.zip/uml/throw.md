```mermaid
classDiagram

class NextLevelToggle{
    - OnTriggerEnter2D(Collider2D collision)
    - OnCollisionEnter2D(Collision2D collision)
    - OnBecameInvisible()
}
```