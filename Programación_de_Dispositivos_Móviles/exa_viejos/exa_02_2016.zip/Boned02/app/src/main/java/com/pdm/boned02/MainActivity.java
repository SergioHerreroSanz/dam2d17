package com.pdm.boned02;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.util.Objects;

public class MainActivity extends AppCompatActivity implements VerFragment.OnSocio{
    ContentResolver cr;
    Uri miUri;
    String [] projection={Constantes.Column.COL_ID,Constantes.Column.COL_SOC,Constantes.Column.COL_BON};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        cr= Objects.requireNonNull(getApplicationContext().getContentResolver());
        miUri=Constantes.CONTENT_URI;
        Cursor cur=cr.query(miUri,projection,null,null,null);
        VerFragment verFragment=new VerFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle,verFragment).commit();
        cur.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onSocioClick(int id, String socio, int bonos) {
        int nuevo=bonos-1;
        if(nuevo>0){
            ContentValues registro=new ContentValues();
            registro.put(Constantes.Column.COL_BON,bonos-1);
            String where=Constantes.Column.COL_ID+"="+id;
            cr.update(miUri,registro,where,null);
        }else{
            String where=Constantes.Column.COL_ID+"="+id;
            cr.delete(miUri,where,null);
            NotificationChannel miCanal;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                miCanal = new NotificationChannel("idBonos", "Bonos", NotificationManager.IMPORTANCE_DEFAULT);
                miCanal.setShowBadge(false);
                NotificationManager mNotificationManager = (NotificationManager) getSystemService(getApplicationContext().NOTIFICATION_SERVICE);
                if (mNotificationManager != null)
                    mNotificationManager.createNotificationChannel(miCanal);
            }
            NotificationManager notificacion = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            Intent intentNotificacion=new Intent(this,MainActivity.class);
            intentNotificacion.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
            Notification.Builder builder=new Notification.Builder(getApplicationContext());
            PendingIntent intentPendienteNoti=PendingIntent.getActivity(this,0,intentNotificacion,PendingIntent.FLAG_UPDATE_CURRENT);
            builder.setContentTitle(socio).setContentText("Nº socio: "+id).setSmallIcon(android.R.drawable.sym_def_app_icon)
                    .setContentIntent(intentPendienteNoti).setOngoing(true);
            if(Build.VERSION.SDK_INT >=Build.VERSION_CODES.O)
                builder.setChannelId("idBonos");
            builder.setAutoCancel(true);
            Notification noti=builder.build();
            notificacion.notify(0,noti);
        }
        VerFragment verFragment=new VerFragment();
        getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle,verFragment).commit();
    }
}
