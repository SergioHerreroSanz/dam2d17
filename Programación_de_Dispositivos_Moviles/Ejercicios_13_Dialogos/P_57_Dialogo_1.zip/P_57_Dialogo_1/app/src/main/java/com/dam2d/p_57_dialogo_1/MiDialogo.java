package com.dam2d.p_57_dialogo_1;

import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

public class MiDialogo extends DialogFragment {
    public interface MiDialogoListener {
        public void onDialogPositiveClick();
        public void onDialogNegativeClick();
    }
    MiDialogoListener miEscuchador;

    @Override public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder
                //Capturar botones
                .setTitle(getString(R.string.dialog_title))
                .setMessage(getString(R.string.dialog_message))
                .setPositiveButton(android.R.string.ok,  new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onDialogPositiveClick();
                    }
                })
                .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        miEscuchador.onDialogNegativeClick();
                    }
                });
        return builder.create();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiDialogoListener) getActivity();
        } catch(ClassCastException e) {
            throw new ClassCastException(getActivity().toString()  + " must implement MiDialogoListener");
        }
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }
}