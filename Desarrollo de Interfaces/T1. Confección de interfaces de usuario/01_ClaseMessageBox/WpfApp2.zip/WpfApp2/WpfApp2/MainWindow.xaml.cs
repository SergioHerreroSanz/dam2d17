﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            const string message = "Mensaje aquí";
            const string caption = "OK";
            var result = MessageBox.Show(message, caption, MessageBoxButton.OK);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            const string message = "Mensaje aquí";
            const string caption = "OKCancel";
            var result = MessageBox.Show(message, caption, MessageBoxButton.OKCancel);
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            const string message = "Mensaje aquí";
            const string caption = "YesNo";
            var result = MessageBox.Show(message, caption, MessageBoxButton.YesNo);
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            const string message = "Mensaje aquí";
            const string caption = "YesNoCancel";
            var result = MessageBox.Show(message, caption, MessageBoxButton.YesNoCancel);
        }
    }
}
