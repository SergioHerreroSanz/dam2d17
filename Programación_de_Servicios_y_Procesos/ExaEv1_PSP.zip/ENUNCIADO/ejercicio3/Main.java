package monedero;

public class Main {

    public static void main(String[] args) {
        Monedero m = new Monedero(100);

        // Declaro los hilos y los almaceno en un Array
        for (int i=0; i<10; i++){
            new Persona(m, i).start();
        }

    }
}
