package com.dam2d.p_69_asincrona_descarga;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URL;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        final ProgressBar progressBar = findViewById(R.id.progressBar);
        final String[] imageUrl = {"https://apod.nasa.gov/apod/image/0905/m31_gendler.jpg", "https://apod.nasa.gov/apod/image/0905/m31_gendler.jpg", "https://apod.nasa.gov/apod/image/0905/m31_gendler.jpg"};
        final int[] imageId = {R.id.imageView, R.id.imageView2, R.id.imageView3};
        final Bitmap[] image = new Bitmap[imageUrl.length];
        Button button = findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new Thread(new Runnable() {
                    public void run() {
                        progressBar.post(new Runnable() {
                            public void run() {
                                progressBar.setProgress(0);
                            }
                        });
                        for (int i = 0; i < imageUrl.length; i++) {
                            Bitmap bitmap = null;
                            try {
                                bitmap = BitmapFactory.decodeStream((InputStream) new URL(imageUrl[i]).getContent());
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                            image[i] = bitmap;
                            progressBar.post(new Runnable() {
                                public void run() {
                                    progressBar.incrementProgressBy(10);
                                }
                            });
                            final int finalI = i;
                            runOnUiThread(new Runnable() {
                                public void run() {
                                    Toast.makeText(getApplicationContext(), "Descargada imagen "+(finalI+1), Toast.LENGTH_SHORT).show();
                                    ImageView imageView = findViewById(imageId[finalI]);
                                    imageView.setImageDrawable(new BitmapDrawable(getResources(), image[finalI]));
                                }
                            });
                        }
                        /*
                        runOnUiThread(new Runnable() {
                            public void run() {
                                for (int i = 0; i < imageUrl.length; i++) {
                                    ImageView imageView = findViewById(imageId[i]);
                                    imageView.setImageDrawable(new BitmapDrawable(getResources(), image[i]));
                                }
                                Toast.makeText(getApplicationContext(), "Finalizado", Toast.LENGTH_SHORT).show();
                            }
                        });
                        */
                    }
                }).start();
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
