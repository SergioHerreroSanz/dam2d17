package com.dam2d.p_19_intent_imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn = findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                EditText editText = findViewById(R.id.editText);
                EditText editText1 = findViewById(R.id.editText2);

                String strPeso = editText.getText().toString();
                String strAltura = editText1.getText().toString();

                if (strPeso.length() > 0) {
                    if (strAltura.length() > 0) {
                        if (Double.parseDouble(strPeso) > 0) {
                            if (Double.parseDouble(strAltura) > 0) {
                                double peso = Double.parseDouble(strPeso);
                                double altura = Double.parseDouble(strAltura) / 100;
                                double imc = peso / (altura * altura);

                                String estado;
                                if (imc < 16) {
                                    estado = "desnutrición de grado 3";
                                } else if (imc < 17) {
                                    estado = "desnutrición de grado 2";
                                } else if (imc < 18.5) {
                                    estado = "desnutrición de grado 1";
                                } else if (imc < 25) {
                                    estado = "un peso ideal";
                                } else if (imc < 30) {
                                    estado = "sobrepeso de grado 1";
                                } else if (imc < 40) {
                                    estado = "sobrepeso de grado 2";
                                } else {
                                    estado = "sobrepeso de grado 3";
                                }

                                String texto = "Tu IMC es :" + imc + ".\n Tienes " + estado + ".";
                                Toast toast3 = Toast.makeText(getApplicationContext(), texto, Toast.LENGTH_LONG);
                                toast3.show();
                            } else {
                                editText1.requestFocus();
                                Toast toast2 = Toast.makeText(getApplicationContext(), "La altura debe de ser mayor que 0.", Toast.LENGTH_LONG);
                                toast2.show();
                            }
                        } else {
                            editText.requestFocus();
                            Toast toast = Toast.makeText(getApplicationContext(), "El peso debe de ser mayor que 0.", Toast.LENGTH_LONG);
                            toast.show();
                        }
                    } else {
                        editText1.requestFocus();
                    }
                } else {
                    editText.requestFocus();
                }
            }
        });

        Button btn2 = findViewById(R.id.button2);
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SegundaActivity.class);
                startActivity(intent);
            }
        });
    }
}
