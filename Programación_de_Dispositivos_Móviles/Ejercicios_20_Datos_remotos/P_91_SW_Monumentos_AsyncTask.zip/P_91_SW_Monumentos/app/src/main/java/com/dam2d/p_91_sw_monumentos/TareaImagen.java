package com.dam2d.p_91_sw_monumentos;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class TareaImagen extends AsyncTask<String, ArrayList<Bitmap>, ArrayList<Bitmap>> {
    @Override
    protected ArrayList<Bitmap> doInBackground(String... strings) {
        ArrayList<Bitmap> bitmapImagen = new ArrayList<Bitmap>();
        for (String url : strings) {
            try {
                URL urlImagen = new URL(url);
                //URLConnection urlConnectionImagen = urlImagen.openConnection();
                InputStream streamImagen = (InputStream) urlImagen.getContent();
                //InputStream streamImagen = urlConnectionImagen.getInputStream();
                bitmapImagen.add(BitmapFactory.decodeStream(streamImagen));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return bitmapImagen;
    }
}
