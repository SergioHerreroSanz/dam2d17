package com.company;

public class Main {

    public static void main(String[] args) {
        Contador c = new Contador();
        c.start();

        //Que pasen 5 segundos
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        //Paro el hilo
        c.interrupt();

    }
}
