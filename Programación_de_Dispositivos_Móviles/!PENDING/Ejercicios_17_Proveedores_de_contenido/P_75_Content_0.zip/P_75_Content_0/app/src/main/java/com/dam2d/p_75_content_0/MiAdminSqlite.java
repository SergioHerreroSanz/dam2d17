package com.dam2d.p_75_content_0;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

public class MiAdminSqlite extends SQLiteOpenHelper {
    private static MiAdminSqlite sInstance;
    private Context context;

    public static synchronized MiAdminSqlite getInstance(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        if (sInstance == null) {
            sInstance = new MiAdminSqlite(context.getApplicationContext(), name, factory, version);
            Log.d("qqq", "" + "init");
            Toast.makeText(context, "Tabla inicializada", Toast.LENGTH_SHORT).show();
        }
        return sInstance;
    }

    public MiAdminSqlite(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + Constantes.TABLA + " (_id INTEGER primary key AUTOINCREMENT, nombre TEXT, tipo TEXT, cantidad INTEGER)");



        Log.d("qqq", "new");
        Toast.makeText(context, "Se ha creado la BD por primera vez", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Constantes.TABLA);
        db.execSQL("CREATE TABLE " + Constantes.TABLA + " (_id INTEGER primary key AUTOINCREMENT, nombre TEXT, tipo TEXT, cantidad INTEGER)");
    }

}
