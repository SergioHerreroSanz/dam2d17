package com.pdm.exa_1_2019_bis;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;

import java.util.Objects;

public class TerceraActivity extends AppCompatActivity implements ItemFragment.OnListFragmentInteractionListener, FijoFragment.MiListenerFijo,MovilFragment.MiListenerMovil {

    private boolean dosFragmentos;
    Fragment fragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tercera);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        if (findViewById(R.id.content_detalle)!=null) {
            dosFragmentos = true;
            fragment=new FijoFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle,fragment).commit();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.tercera, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_settings) {
            SharedPreferences prefe = getSharedPreferences("datos", Context.MODE_PRIVATE);
            int veces = prefe.getInt("veces", 1);
            Toast.makeText(getApplicationContext(), "El número de veces que has pasado por aquí es " + veces, Toast.LENGTH_LONG).show();
            SharedPreferences.Editor editor = prefe.edit();
            editor.putInt("veces", veces + 1);
            editor.apply();
        } else {
            return super.onOptionsItemSelected(item);
        }
        return true;
    }
    @Override
    public void onListFragmentInteraction(int id) {
        if (dosFragmentos) {
            switch (id) {
                case 0:
                    fragment = new FijoFragment();
                    break;
                case 1:
                    fragment = new MovilFragment();
                    break;
            }
            getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle, fragment).commit();
        } else {
            Bundle bundle = new Bundle();
            bundle.putInt("seleccionado", id);
            Intent intent = new Intent(this, DetalleActivity.class);
            intent.putExtras(bundle);
            startActivity(intent);
        }
    }

    @Override
    public void onFijoTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:976444444"));
        startActivity(intent);
    }

    @Override
    public void onMovilTocado() {
        Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:666666666"));
        startActivity(intent);
    }
}
