package com.dam2d.exa_01_2017_2.ui;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.dam2d.exa_01_2017_2.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Opcion1Fragment extends Fragment {


    public Opcion1Fragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_opcion1, container, false);
        Button button = view.findViewById(R.id.button2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miEscuchador.onOpcion1LaunchIntent();
            }
        });
        return view;
    }

    //Interfaz para poder realizar acciones en el main. (MiDialogo)
    public interface Opcion1Listener {
        public void onOpcion1LaunchIntent();
    }

    Opcion1Listener miEscuchador;

    //Instanciar el Listener (MiDialogo)
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (Opcion1Listener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement Opcion1Listener");
        }
    }

    //Acciones a realizar cuando se sale sin realizar acciones (MiDialogo)
    @Override
    public void onDetach() {
        super.onDetach();
        miEscuchador = null;
    }
}
