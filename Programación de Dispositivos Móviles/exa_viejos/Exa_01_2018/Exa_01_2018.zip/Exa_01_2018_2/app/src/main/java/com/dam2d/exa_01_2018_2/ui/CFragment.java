package com.dam2d.exa_01_2018_2.ui;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dam2d.exa_01_2018_2.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class CFragment extends Fragment {


    public CFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_c, container, false);

        String texto = miEscuchador.onCSetPreferenceString();
        TextView textView = view.findViewById(R.id.textView4);
        textView.setText(texto);

        // Inflate the layout for this fragment
        return view;
    }

    public interface CListener {
        public String onCSetPreferenceString();
    }

    CListener miEscuchador;

    //Instanciar el Listener
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (CListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " must implement CListener");
        }
    }

    //Acciones a realizar cuando se sale sin realizar acciones
    @Override
    public void onDetach() {
        super.onDetach();
        miEscuchador = null;
    }
}
