package com.dam2d.exa_01_2017_2;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;

import com.dam2d.exa_01_2017_2.ui.Opcion1Fragment;
import com.dam2d.exa_01_2017_2.ui.Opcion2Fragment;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import android.view.View;

import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;

import java.util.prefs.Preferences;

public class MainActivity extends AppCompatActivity implements Opcion1Fragment.Opcion1Listener, ItemFragment.OnListFragmentInteractionListener {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        int orientacion = getResources().getConfiguration().orientation;
        if (orientacion != Configuration.ORIENTATION_LANDSCAPE) {
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            mAppBarConfiguration = new AppBarConfiguration.Builder(
                    R.id.nav_Default, R.id.nav_Opcion1, R.id.nav_Opcion2)
                    .setDrawerLayout(drawer)
                    .build();
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
            NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
            NavigationUI.setupWithNavController(navigationView, navController);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }


    @Override
    public void onOpcion1LaunchIntent() {
        Intent miIntent = new Intent(getApplicationContext(), PreferencesActivity.class);
        startActivity(miIntent);
    }

    @Override
    public void onListFragmentInteraction(int id) {
        Fragment fragment = null;
        switch (id) {
            case 1:
                fragment = new Opcion1Fragment();
                break;
            case 2:
                fragment = new Opcion2Fragment();
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.content_detalle, fragment).commit();
    }

}
