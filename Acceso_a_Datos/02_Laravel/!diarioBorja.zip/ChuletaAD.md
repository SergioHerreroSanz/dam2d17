composer require laravel/ui

$fillable]
$timestamps

create|store
show
update|edit
destroy

redirect()
compact()

Modelo::find(\$id)
	  ::findOrFail()
	  ::all()
	  ::destroy()
	  ::create(array_assoc)
	  ->delete()
	  ->update()
	  ->save()

ELOQUENT
orderBy(col)
where('nombre', 'Juan')
orWhere()
first()
get()
pluck('col0', 'col1')
paginate(10)

hasMany('App\Jugador')
belongsTo('App\Equipo')

Schema::create('alumnos', function (Blueprint $table) {
    bigIncrements('id');
    string('nombre', 30);
    integer('nota');
    unsignedBigInteger('grupo_id');
    foreign('grupo_id')->references('id')->on('grupos');
    timestamps();
});

$request->validate(
    [
        'nombre' => 'required',
        'nota' => 'required'
    ],
    [
        'nombre.required' => 'El nombre es obligatorio',
        'nota.required'  => 'La nota es necesaria'
    ]
);

public function __construct()
    {
        $this->middleware('auth')
            ->except([
                'index',
                'show',
                'json'
            ]);
    }
	
getElementById(id)

onclick
onmouseover

innerHTML
value
href
style.fontSize
outerHTML
onsubmit = "return validar()";

setTimeout(nomFunc, 2000);
setTimeout(() => {}, timeout);
interval(funcion, tiempo);

fetch(url);
fetch(url, opciones);
    .then(function(response)){}
    .then(function(data))
    .catch(function(error){})
return response.json(); // lo que capturas
nodo1.inssertHTML
