package com.dam2d.graficoszoom;

import android.graphics.Bitmap;

public class Grafico {
    private Bitmap miBitmap;
    private int pos_x, pos_y;
    private int desp_x, desp_y;
    private int ancho, alto;
    private MiVista view;

    Grafico(MiVista view, Bitmap miBitmap) {
        this.view = view;
        this.miBitmap = miBitmap;
        ancho = miBitmap.getWidth();
        alto = miBitmap.getHeight();
    }

    Bitmap getMiBitmap() {
        return miBitmap;
    }

    public void setMiBitmap(Bitmap miBitmap) {
        this.miBitmap = miBitmap;
    }

    int getPos_x() {
        return pos_x;
    }

    void setPos_x(int pos_x) {
        this.pos_x = pos_x;
    }

    int getPos_y() {
        return pos_y;
    }

    void setPos_y(int pos_y) {
        this.pos_y = pos_y;
    }

    int getDesp_x() {
        return desp_x;
    }

    void setDesp_x(int desp_x) {
        this.desp_x = desp_x;
    }

    int getDesp_y() {
        return desp_y;
    }

    void setDesp_y(int desp_y) {
        this.desp_y = desp_y;
    }

    int getAncho() {
        return ancho;
    }

    void setAncho(int ancho) {
        this.ancho = ancho;
    }

    int getAlto() {
        return alto;
    }

    void setAlto(int alto) {
        this.alto = alto;
    }

    public MiVista getView() {
        return view;
    }

    public void setView(MiVista view) {
        this.view = view;
    }
}
