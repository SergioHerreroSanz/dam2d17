package com.dam2d.p_44_fragmentos_05;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ToggleButton;


/**
 * A simple {@link Fragment} subclass.
 */
public class EstaticoFragment extends Fragment {

    OnBotonTocadoListener miListener;

    public EstaticoFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_estatico, container, false);
        final ToggleButton toggleButton = view.findViewById(R.id.toggleButton);
        final FrameLayout frameLayout = view.findViewById(R.id.estaticoLayout);
        toggleButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int colorNuevo;
                if (toggleButton.isChecked()) colorNuevo = R.color.colorPrimary;
                else colorNuevo = R.color.colorAccent;
                miListener.onBotonTocado(colorNuevo);
            }
        });


        try {
            miListener = (OnBotonTocadoListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString() + " falta implementar listener Toogle");
        }

        return view;
    }

    public interface OnBotonTocadoListener {
        void onBotonTocado(int color);
    }


}
