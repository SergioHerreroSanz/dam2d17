package com.dam2d.p_75_content_0;

import android.content.UriMatcher;
import android.net.Uri;

public class Constantes {
    // Constantes para la Base de datos
    static final String BD_NOMBRE = "platos.db";
    static final int BD_VERSION = 1;

    //Autoridad del Content Provider
    static final String AUTHORITY = "com.dam2d.p_75_content_0";
    // Representación de la tabla a consultar
    static final String TABLA = "platos";
    // URI de contenido principal
    static final String uri = "content://" + AUTHORITY + "/" + TABLA;
    static final Uri CONTENT_URI =Uri.parse(uri);

    // Para URIs de multiples registros
    static final int TODOS = 0;
    // Para URIS de un solo registro
    static final int UNO = 1;

    // Comparador de URIs de contenido
    static final UriMatcher uriMatcher;
    // Asignación de URIs
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, TABLA, TODOS);
        uriMatcher.addURI(AUTHORITY, TABLA + "/#", UNO);
    }

    //Tipo MIME que devuelve la consulta de una sola fila
    static final String MIME_SIMPLE ="vnd.android.cursor.item/vnd.pdm." + TABLA;
    //Tipo MIME que devuelve la consulta de todas las filas
    static final String MIME_MULTIPLE ="vnd.android.cursor.dir/vnd.pdm." + TABLA;
}
