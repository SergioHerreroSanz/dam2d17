package com.dam2d.exa_01_2018_2.item;

import android.graphics.drawable.Drawable;

public class Item {
    public Drawable imagen;
    public int id;

    public Item(int id, Drawable imagen) {
        this.id = id;
        this.imagen = imagen;
    }

    public int getId() {
        return id;
    }

    public Drawable getImagen() {
        return imagen;
    }
}
