package com.pdm.exa_1_2019_bis;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.Objects;


/**
 * A simple {@link Fragment} subclass.
 */
public class SeguirFragment extends Fragment {

    public interface MiListener {
        void onClickTocado();
    }

    private MiListener miEscuchador;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(Objects.requireNonNull(getActivity()).toString()
                    + " must implement MiDialogoListener");
        }
    }

    public SeguirFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_seguir, container, false);
        Button button=view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miEscuchador.onClickTocado();
            }
        });
        return view;
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }

}
