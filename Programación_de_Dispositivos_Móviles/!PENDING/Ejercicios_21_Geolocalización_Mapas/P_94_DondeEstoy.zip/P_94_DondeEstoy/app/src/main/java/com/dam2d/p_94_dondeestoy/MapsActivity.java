package com.dam2d.p_94_dondeestoy;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.ResolvableApiException;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResponse;
import com.google.android.gms.location.SettingsClient;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ConstraintLayout layoutMain;
    LocationRequest locRequest;
    Location ubicacion;
    private FusedLocationProviderClient mFusedLocationClient;
    boolean primeraVez = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        boolean valido = comprobarValidezDispositivo();
        if (!valido) {
            finish();
        }
        if (ContextCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            pedirPermiso();
        } else {
            obtenerLocalizacion();
        }
    }

    private boolean comprobarValidezDispositivo() {
        GoogleApiAvailability googleApiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = googleApiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (resultCode == ConnectionResult.SERVICE_INVALID) {
                Toast.makeText(this, "Dispositivo sin Google Play Services", Toast.LENGTH_LONG).show();
                return false;
            }
            if (googleApiAvailability.isUserResolvableError(resultCode)) {
                googleApiAvailability.getErrorDialog(this, resultCode, 1000).show();
            } else {
                Toast.makeText(this, "Otros problemas ", Toast.LENGTH_LONG).show();
                return false;
            }
        }
        return true;
    }

    private void pedirPermiso() {
        //Permiso localización
        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
            final Activity activity = this;
            Snackbar.make(layoutMain, "Es preciso permiso de ubicación en modo alta precisión ", Snackbar.LENGTH_INDEFINITE).setAction("OK", new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ActivityCompat.requestPermissions(activity, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
                }
            }).show();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 123) {
            if (grantResults.length == 1 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                obtenerLocalizacion();
            } else {
                Snackbar.make(layoutMain, "Sin el permiso, no puedo realizar la acción", Snackbar.LENGTH_LONG).show();
            }
        }
    }

    private void obtenerLocalizacion() {
        //Permiso concedido
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.


        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            mFusedLocationClient.getLastLocation()
                    .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            actualizarLayout(location);
                        }
                    });
        }


    }

    private void actualizarLayout(Location location) {
        if (location != null) {
            ubicacion = location;

            obtenerDireccion(location);
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                    .findFragmentById(R.id.map);
            mapFragment.getMapAsync(this);
        }
    }

    private String obtenerDireccion(Location location) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        List<Address> listaDirecciones = null;
        String textoDireccion = null;
        try {
            listaDirecciones = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            // Nº de direcciones que se desean
        } catch (IOException ioException) {
            textoDireccion = "Imposible obtener dirección";
        } catch (IllegalArgumentException illegalArgumentException) {
            // Catch invalid latitude or longitude values.
            textoDireccion = "Valores no válidos";
        }

        if (listaDirecciones == null || listaDirecciones.size() == 0) {
            if (textoDireccion == null) {
                textoDireccion = "No encontrada dirección";
            }
        } else {
            Address direccion = listaDirecciones.get(0);
            /* "formato feo"
                textoDireccion=direccion.getAddressLine(0);
            */
            textoDireccion = direccion.getThoroughfare() + " " + direccion.getSubThoroughfare() + "\n" + direccion.getPostalCode();
            textoDireccion = textoDireccion + " " + direccion.getLocality() + " - " + direccion.getCountryName();
        }
        return textoDireccion;
    }

    private void obtenerLocalización() {

        locRequest = new LocationRequest();
        locRequest.setInterval(2000);
        locRequest.setFastestInterval(1000);
        locRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder().addLocationRequest(locRequest);
        SettingsClient client = LocationServices.getSettingsClient(this);
        Task<LocationSettingsResponse> task = client.checkLocationSettings(builder.build());

        task.addOnSuccessListener(this, new OnSuccessListener<LocationSettingsResponse>() {
            @Override
            public void onSuccess(LocationSettingsResponse locationSettingsResponse) {
                recibeActualizacion();
            }
        });
        task.addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                if (e instanceof ResolvableApiException) {
                    // Location settings are not satisfied, but this can be fixed
                    // by showing the user a dialog.
                    try {
                        // Show the dialog by calling startResolutionForResult(),
                        // and check the result in onActivityResult().
                        ResolvableApiException resolvable = (ResolvableApiException) e;
                        resolvable.startResolutionForResult(MapsActivity.this, 0x1);
                    } catch (IntentSender.SendIntentException sendEx) {
                        // Ignore the error.
                    }
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 111) {
            switch (resultCode) {
                case Activity.RESULT_OK:
                    recibeActualizacion();
                    break;
                case Activity.RESULT_CANCELED:
                    Toast.makeText(getApplicationContext(), "No se han realizado los cambios de configuración necesarios", Toast.LENGTH_SHORT).show();
                    finish();
                    break;
            }
        }
    }

    private void recibeActualizacion() {
        LocationCallback mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
            }
        };
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
            mFusedLocationClient.requestLocationUpdates(locRequest, mLocationCallback, null);
        } else {
            Toast.makeText(getApplicationContext(), "Estáte quieto con los permisos!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        obtenerLocalizacion();
        //MiMarcador
        LatLng miPosActual = new LatLng(ubicacion.getLatitude(), ubicacion.getLongitude());
        String direccion = obtenerDireccion(ubicacion);
        mMap.addMarker(new MarkerOptions().position(miPosActual).title(direccion));
        if (primeraVez) {
            CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(miPosActual)
                    .zoom(15)
                    .build();
            CameraUpdate camUpd = CameraUpdateFactory.newCameraPosition(cameraPosition);
            mMap.animateCamera(camUpd);
            primeraVez = false;
        }

/*
        // Add a marker in Sydney and move the camera
        LatLng miPos = new LatLng(-34, 151);
        mMap.addMarker(new MarkerOptions().position(miPos).title("Marker in Sydney"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(miPos));
 */
    }
}
