package com.pdm.boned02;

import android.content.UriMatcher;
import android.net.Uri;
import android.provider.BaseColumns;

public class Constantes {
    static final String DB_NAME="martinboned.db";
    static final int DB_VERSION=1;
    private static final String AUTHORITY="com.pdm.boned";
    static final String TABLA="socios";
    private static final String uri = "content://" + AUTHORITY + "/" + TABLA;
    static final Uri CONTENT_URI =Uri.parse(uri);
    static final int TODOS = 0;
    static final int UNO = 1;
    static final UriMatcher uriMatcher;
    static {
        uriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
        uriMatcher.addURI(AUTHORITY, TABLA, TODOS);
        uriMatcher.addURI(AUTHORITY, TABLA + "/#", UNO);
    }
    static final String MIME_SIMPLE ="vnd.android.cursor.item/vnd.pdm." + TABLA;
    static final String MIME_MULTIPLE ="vnd.android.cursor.dir/vnd.pdm." + TABLA;
    static class Column implements BaseColumns {
        private Column() {}
        static final String COL_ID = "_id";
        static final String COL_SOC = "socio";
        static final String COL_BON = "bonos";
    }
}
