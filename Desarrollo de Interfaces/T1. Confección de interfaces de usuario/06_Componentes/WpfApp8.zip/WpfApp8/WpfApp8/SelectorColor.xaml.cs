﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp8
{
    /// <summary>
    /// Lógica de interacción para SelectorColor.xaml
    /// </summary>
    public partial class SelectorColor : Window
    {
        public SelectorColor()
        {
            InitializeComponent();
        }

        private void Button_Click_Cancelar(object sender, RoutedEventArgs e)
        {
            Close();
        }


        private void Button_Click_Aceptar(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void TextBox_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            int val;
            Boolean resultado = int.TryParse(((TextBox)sender).Text + e.Text, out val) && val >= 0 && val <= 255;

            if (val > 255) { ((TextBox)sender).Text = "255"; }

            e.Handled = !resultado;
        }

        private void TxtBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            textBox.Dispatcher.BeginInvoke(new Action(() => textBox.SelectAll()));
        }

        private void TxtRojo_TextChanged(object sender, TextChangedEventArgs e)
        {
            Txt_TextChanged(txtRojo, scbRojo);
        }

        private void TxtVerde_TextChanged(object sender, TextChangedEventArgs e)
        {
            Txt_TextChanged(txtVerde, scbVerde);
        }

        private void TxtAzul_TextChanged(object sender, TextChangedEventArgs e)
        {
            Txt_TextChanged(txtAzul,scbAzul);
        }

        /// <summary>
        /// Modifica el valor del parámetro txt con el valor contenido en el parámetro scb y cambia el fondo del elemento rectangle.
        /// </summary>
        /// <param name="txt">TextBox al que modificar su valor</param>
        /// <param name="scb">ScrollBar del que obtener el valor</param>
        private void Txt_TextChanged(TextBox txt, System.Windows.Controls.Primitives.ScrollBar scb)
        {
            try
            {
                byte rojo = byte.Parse(txtRojo.Text);
                byte verde = byte.Parse(txtVerde.Text);
                byte azul = byte.Parse(txtAzul.Text);

                rectangle.Fill = new SolidColorBrush(Color.FromRgb(rojo, verde, azul));

                scb.Value = byte.Parse(txt.Text);
            }
            catch (Exception ex) { Console.WriteLine(ex); }
        }

        private void ScbRojo_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Scb_ValueChanged(scbRojo, txtRojo);
        }

        private void ScbVerde_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Scb_ValueChanged(scbVerde, txtVerde);
        }

        private void ScbAzul_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Scb_ValueChanged(scbRojo, txtRojo);
        }

        /// <summary>
        /// Modifica el valor del parámetro scb con el texto (parseado) contenido en el parámetro txt y cambia el fondo del elemento rectangle.
        /// </summary>
        /// <param name="scb">ScrollBar al que modificar su valor</param>
        /// <param name="txt">TextBox del que obtener el valor</param>
        private void Scb_ValueChanged(System.Windows.Controls.Primitives.ScrollBar scb, TextBox txt)
        {
            byte rojo = byte.Parse(txtRojo.Text);
            byte verde = byte.Parse(txtVerde.Text);
            byte azul = byte.Parse(txtAzul.Text);

            rectangle.Fill = new SolidColorBrush(Color.FromRgb(rojo, verde, azul));

            txt.Text = scb.Value.ToString();
        }
    }
}
