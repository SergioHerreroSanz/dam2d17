package com.pdm.p_13_eventos_06;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.button);
        Button button1 = findViewById(R.id.button2);
        ImageButton imageButton = findViewById(R.id.imageButton);
        button.setOnClickListener(this);
        button1.setOnClickListener(this);
        imageButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        EditText editText = findViewById(R.id.editText);
        EditText editText1 = findViewById(R.id.editText2);
        double valor_conocido, valor_buscado;
        switch (v.getId()) {
            case R.id.button:
                String euros = editText.getText().toString();
                if (euros.trim().length() == 0)
                    editText.requestFocus();
                else {
                    valor_conocido = Double.parseDouble(euros);
                    valor_buscado = valor_conocido * 1.1186;
                    editText1.setText(String.valueOf(valor_buscado));
                }
                break;
            case R.id.button2:
                String dolares = editText1.getText().toString();
                if (dolares.trim().length() == 0)
                    editText1.requestFocus();
                else {
                    valor_conocido = Double.parseDouble(dolares);
                    valor_buscado = valor_conocido * 0.8904;
                    editText.setText(String.valueOf(valor_buscado));
                }
                break;
            default:
                finish();
        }
    }
}
