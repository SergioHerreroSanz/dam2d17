package com.dam2d.p_91_sw_monumentos;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        final RecyclerView recView = findViewById(R.id.recyclerView);
        recView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutmanager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recView.setLayoutManager(layoutmanager);

        boolean acceso = isNetworkAvailable();
        if (acceso) {
            String url = "https://www.zaragoza.es/sede/servicio/monumento.json";
            Log.d("qqq", "Llego");
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.d("qqq", "Llego2");
                    parsearJSON(response, recView);
                    Log.d("qqq", "Llego3");
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), R.string.imposible, Toast.LENGTH_LONG).show();
                    error.printStackTrace();

                }
            });
            MySingleton.getInstance(this).addToRequestQueue(request);
        }
    }

    private void parsearJSON(JSONObject devuelto, RecyclerView recyclerView) {
        // Necesitamos un ArrayList para los datos de los restaurantes
        ArrayList<Item> datos = new ArrayList<>();
        // Tenemos que analizar el JSON, en el navegador hemos visto que del conjunto de datos,
        // a nosotros nos interesan los que están en el objeto llamado response
        try {
            // dentro de ese objeto nos interesa el array de nombre docs
            JSONArray datosQueNosInteresan = devuelto.getJSONArray("result");
            // bucle para cada uno de los restaurantes que aparecen
            for (int i = 0; i < datosQueNosInteresan.length(); i++) {
                // Dentro de ese conjunto hay un objeto JSON para cada monumento
                JSONObject monumento;
                try {
                    monumento = datosQueNosInteresan.getJSONObject(i);
                    // De ese objeto por fin ya podemos extraer los datos
                    // que nos interesan a través de los nombres de sus etiquetas
                    String nombre = monumento.getString("title");
                    String direccion = monumento.getString("address");
                    String stringImagen = monumento.getString("image");
                    Drawable drawableImagen;
                    ImageRequest request = new ImageRequest(stringImagen, new Response.Listener<Bitmap>() {
                        @Override
                        public void onResponse(Bitmap bitmap) {
                            drawableImagen = new BitmapDrawable(getResources(), bitmap);
                        }
                    }, 0, 0, null, null, new Response.ErrorListener() {
                        public void onErrorResponse(VolleyError error) {
                            drawableImagen = null;
                        }
                    });
                    RequestQueue queue = Volley.newRequestQueue(this);
                    queue.add(request);
                    Drawable imagen;
                    // Añadimos la pareja anterior a la lista de restaurantes
                    Log.d("qqq", nombre + " | " + direccion);
                    datos.add(new Item(nombre, direccion, imagen));
                    Log.d("qqq", nombre + " | " + direccion);
                } catch (JSONException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    e.printStackTrace();
                }
            }
            //Construimos el adaptador y se lo añadimos al recycler
            MiAdapter miAdaptador = new MiAdapter(datos);
            recyclerView.setAdapter(miAdaptador);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public boolean isNetworkAvailable() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo redActiva = cm.getActiveNetworkInfo();
        return redActiva != null && redActiva.isAvailable() && redActiva.isConnected();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
