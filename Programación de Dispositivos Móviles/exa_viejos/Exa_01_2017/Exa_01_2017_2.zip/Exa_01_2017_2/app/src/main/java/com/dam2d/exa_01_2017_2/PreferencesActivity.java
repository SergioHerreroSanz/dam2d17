package com.dam2d.exa_01_2017_2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import java.util.prefs.Preferences;

public class PreferencesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preferences);

        SharedPreferences prefe = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = prefe.edit();
        int nVez = prefe.getInt("nVez",1);
        String textoPreferencia=getString(R.string.Preferences_TextView3_text, nVez);

        TextView textView = findViewById(R.id.textView3);
        textView.setText(textoPreferencia);

        editor.putLong("nVez", nVez+1);
        editor.commit();
    }
}
