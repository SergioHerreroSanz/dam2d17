package com.pdm.exa_1_2019_bis;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements MiDialogo.MiDialogoListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        DialogFragment nuevoFragmento = new MiDialogo();
        nuevoFragmento.show(getSupportFragmentManager(), "dialogo");
    }

    @Override
    public void onSeguir() {
        Intent intent=new Intent(getApplicationContext(),SegundaActivity.class);
        startActivity(intent);
    }

    @Override
    public void onAcabar() {
        finish();
    }

    @Override
    public void onCancelar() {
        DialogFragment nuevoFragmento = new MiDialogo();
        nuevoFragmento.show(getSupportFragmentManager(), "dialogo");
    }
}
