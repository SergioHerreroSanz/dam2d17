package com.pdm.p_32_spinner_personalizado_02;

import android.graphics.drawable.Drawable;

class Item {
    /*
     * simplemente es una clase que contendrá las variables necesarias para
     * almacenar los elementos que más tarde queremos que aparezcan en el
     * Spinner. En nuestro caso:
     * long id: posición del ítem dentro de la lista
     * String api: texto que aparece en el ítem
     * Drawable imagen: imagen que aparece en el ítem
     */
    private long id;
    private String api;
    private Drawable imagen;

    Item(long id, String api, Drawable imagen) {
        this.id = id;
        this.api = api;
        this.imagen = imagen;
    }

    long getId() {
        return id;
    }

    String getApi() {
        return api;
    }

    Drawable getImagen() {
        return imagen;
    }
}
