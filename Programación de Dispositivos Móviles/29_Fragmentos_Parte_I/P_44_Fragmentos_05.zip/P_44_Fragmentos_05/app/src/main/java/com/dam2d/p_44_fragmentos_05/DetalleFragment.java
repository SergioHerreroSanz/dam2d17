package com.dam2d.p_44_fragmentos_05;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;

import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class DetalleFragment extends Fragment {

    private static final String ID_CLAVE = "chequeado";
    private int seleccionado;
    private Context contexto;

    public DetalleFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        contexto = context;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle recibidos = getArguments();
        seleccionado = recibidos.getInt(ID_CLAVE);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_detalle, container, false);
        String texto = null;
        Drawable imagen = null;
        switch (seleccionado) {
            case R.id.radioButton:
                texto = getString(R.string.zaragoza);
                imagen = ContextCompat.getDrawable(contexto, R.drawable.zaragoza);
                break;
            case R.id.radioButton2:
                texto = getString(R.string.huesca);
                imagen = ContextCompat.getDrawable(contexto, R.drawable.huesca);
                break;
            case R.id.radioButton3:
                texto = getString(R.string.teruel);
                imagen = ContextCompat.getDrawable(contexto, R.drawable.teruel);
                break;
        }
        TextView textView = view.findViewById(R.id.textView);
        textView.setText(texto);
        ImageView imageView = view.findViewById(R.id.imageView);
        imageView.setImageDrawable(imagen);
        return view;
    }
}
