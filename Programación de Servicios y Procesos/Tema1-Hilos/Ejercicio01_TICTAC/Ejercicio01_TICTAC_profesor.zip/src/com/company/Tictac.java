package com.company;

public class Tictac extends Thread{

    String texto;

    public Tictac(String texto) {
        this.texto = texto;
    }

    @Override
    public void run() {
        for (int i=0; i < 10; i++){
            System.out.println(texto + " " + i);
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
