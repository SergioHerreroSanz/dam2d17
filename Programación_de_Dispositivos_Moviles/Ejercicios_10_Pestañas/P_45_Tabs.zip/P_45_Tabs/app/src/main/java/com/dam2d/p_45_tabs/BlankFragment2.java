package com.dam2d.p_45_tabs;


import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class BlankFragment2 extends Fragment {

    private String mNumTab;
    private int posicion;

    public BlankFragment2(String param1,int param2, Context context) {
        // Required empty public constructor
        mNumTab = param1;
        posicion = param2;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_blank_2, container, false);
        TextView textView = view.findViewById(R.id.textViewBlank2);
        //textView.setText(getResources().getStringArray(R.array.imagen)[posicion]);
        textView.setText(getResources().getStringArray(R.array.descripcion)[posicion]);
        return view;
    }

}
