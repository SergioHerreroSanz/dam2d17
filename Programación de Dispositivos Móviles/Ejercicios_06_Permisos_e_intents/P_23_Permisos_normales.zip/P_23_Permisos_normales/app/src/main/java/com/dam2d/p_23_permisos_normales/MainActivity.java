package com.dam2d.p_23_permisos_normales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnWeb = findViewById(R.id.button);
        Button btnMap = findViewById(R.id.button2);
        Button btnEmail = findViewById(R.id.button3);

        btnWeb.setOnClickListener(this);
        btnMap.setOnClickListener(this);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.button:
                Uri url = Uri.parse("http://www.iespabloserrano.es/");
                Intent intentWeb = new Intent(Intent.ACTION_VIEW, url);
                startActivity(intentWeb);
                break;
            case R.id.button2:
                Uri location = Uri.parse("geo:41.6442784,-0.8637156?z=17");
                Intent intentMap = new Intent(Intent.ACTION_VIEW, location);
                startActivity(intentMap);
                break;
            case R.id.button3:
                String email = "bsoler@iespabloserrano.com";
                Intent intentEmail = new Intent(Intent.ACTION_SEND);
                intentEmail.setType("text/plain");
                intentEmail.putExtra(Intent.EXTRA_EMAIL, new String[]{email});
                intentEmail.putExtra(Intent.EXTRA_SUBJECT, "");
                intentEmail.putExtra(Intent.EXTRA_TEXT, "");
                startActivity(intentEmail);
                break;
        }
    }
}
