package monedero;

public class Persona extends Thread{

    private int id;
    private Monedero monedero;
    private int miDinero;

    public Persona(Monedero monedero, int id) {
        this.monedero = monedero;
        this.id = id;
        this.miDinero = 0;
    }

    @Override
    public void run() {
        for(int i=0; i<10; i++){
            try {
                miDinero += monedero.sacarDinero(10);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        System.out.println(id+" "+miDinero);
    }

}
