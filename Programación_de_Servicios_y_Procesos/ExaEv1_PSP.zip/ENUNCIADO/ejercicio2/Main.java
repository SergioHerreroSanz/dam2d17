package examen_Puente;

public class Main {
    public static void main(String[] args) {

        /* En esta clase generamos la simulacion
         * No teneis que generar un simulacion completa
         * Solo me sirve para saber como invocais los hilos y los relacionais con la clase Puente
         *
         * Recordar que teneis que generar algunos coches del Norte y otros del Sur
         *
         * */

    }
}
