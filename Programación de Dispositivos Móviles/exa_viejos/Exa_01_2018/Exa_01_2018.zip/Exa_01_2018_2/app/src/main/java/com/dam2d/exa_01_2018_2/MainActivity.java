package com.dam2d.exa_01_2018_2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Bundle;

import com.dam2d.exa_01_2018_2.dialog.BDialog;
import com.dam2d.exa_01_2018_2.dialog.ShutdownDialog;
import com.dam2d.exa_01_2018_2.item.Item;
import com.dam2d.exa_01_2018_2.item.ItemFragment;
import com.dam2d.exa_01_2018_2.ui.AFragment;
import com.dam2d.exa_01_2018_2.ui.BFragment;
import com.dam2d.exa_01_2018_2.ui.CFragment;
import com.dam2d.exa_01_2018_2.ui.InicioFragment;

import android.view.MenuItem;
import android.view.View;

import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;

import androidx.drawerlayout.widget.DrawerLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.Menu;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements ShutdownDialog.ShutdownListener, AFragment.AListener, BFragment.BListener, BDialog.BDialogListener, CFragment.CListener, ItemFragment.OnListFragmentInteractionListener {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        int orientation = getResources().getConfiguration().orientation;
        if (orientation == Configuration.ORIENTATION_PORTRAIT) {
            DrawerLayout drawer = findViewById(R.id.drawer_layout);
            NavigationView navigationView = findViewById(R.id.nav_view);
            // Passing each menu ID as a set of Ids because each
            // menu should be considered as top level destinations.
            mAppBarConfiguration = new AppBarConfiguration.Builder(
                    R.id.inicioFragment, R.id.AFragment, R.id.BFragment,
                    R.id.CFragment)
                    .setDrawerLayout(drawer)
                    .build();
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
            NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
            NavigationUI.setupWithNavController(navigationView, navController);
            navigationView.setItemIconTintList(null);
        } else {
            Fragment fragment = new InicioFragment();
            getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout5, fragment).commit();
        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_shutdown:
                DialogFragment nuevoFragmento = new ShutdownDialog();
                nuevoFragmento.show(getSupportFragmentManager(), "ShutdownDialog");
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //Acciones boton apagar AppBar
    @Override
    public void onPositiveShutdown() {
        finish();
    }

    @Override
    public void onNegativeShutdown() {
        Toast.makeText(this, getString(R.string.ShutdownDialog_negativeMessage), Toast.LENGTH_LONG).show();
    }

    //Acciones AFragment
    @Override
    public void onAGuardar() {
        SharedPreferences prefe = getPreferences(MODE_PRIVATE);
        SharedPreferences.Editor editor = prefe.edit();
        Button button = findViewById(R.id.button);
        EditText editText = findViewById(R.id.editText);
        TextView textView = findViewById(R.id.textView2);

        String texto = editText.getText().toString();

        editor.putBoolean("firstTime", false);
        editor.putString("text", texto);
        editor.apply();

        textView.setText(R.string.a_TextView2_text3);
        editText.setVisibility(View.INVISIBLE);
        button.setVisibility(View.INVISIBLE);
    }

    //Acciones BFragment
    @Override
    public void onBLaunchDialog() {
        DialogFragment nuevoFragmento = new BDialog();
        nuevoFragmento.show(getSupportFragmentManager(), "BDialog");
    }

    //Acciones BDialog
    @Override
    public void onBDialogPositiveClick() {
        Intent i = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:976491015"));
        startActivity(i);
    }

    @Override
    public void onBDialogNegativeClick() {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("http://www.iespabloserrano.es"));
        startActivity(i);
    }

    //Acciones CFragment
    @Override
    public String onCSetPreferenceString() {
        SharedPreferences prefe = getPreferences(MODE_PRIVATE);
        String textoPreferencia = prefe.getString("text", "");
        return getString(R.string.c_TextView4_text, textoPreferencia);
    }

    //Variación Horizontal
    @Override
    public void onListFragmentInteraction(Item item) {
        Fragment fragment = new InicioFragment();
        switch (item.id) {
            case 0:
                fragment = new InicioFragment();
                break;
            case 1:
                fragment = new AFragment();
                break;
            case 2:
                fragment = new BFragment();
                break;
            case 3:
                fragment = new CFragment();
                break;
        }
        getSupportFragmentManager().beginTransaction().replace(R.id.frameLayout5, fragment).commit();
    }
}
