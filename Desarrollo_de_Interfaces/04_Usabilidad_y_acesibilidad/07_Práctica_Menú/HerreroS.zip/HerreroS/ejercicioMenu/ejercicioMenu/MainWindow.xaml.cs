﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ejercicioMenu
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú File");
        }

        private void MenuItem_Click2(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú Edit");
        }

        private void MenuItem_Click3(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú View");
        }

        private void MenuItem_Click4(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú Settings");
        }

        private void MenuItem_Click5(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú Extensions");
        }

        private void MenuItem_Click6(object sender, RoutedEventArgs e)
        {
            SettingsWindow settingsWindow = new SettingsWindow();
            settingsWindow.Show();
        }

        private void MenuItem_Click7(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Acción realizada", "Menú Help");
        }
    }
}
