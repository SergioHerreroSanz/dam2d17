package com.pdm.p_33_spinner_intent_01;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Objects;

public class SegundaActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        if (getIntent().getExtras() != null) {
            Bundle bundle=getIntent().getExtras();
            final String cursoEscogido=bundle.getString("cursoEscogido");
            TextView textView = findViewById(R.id.textView2);
            textView.setText(String.format("Lista de asignaturas de %s", cursoEscogido));
            String[] asignaturas;
            if (Objects.equals(cursoEscogido, "1º")) {
                asignaturas = getResources().getStringArray(R.array.asignaturas1);
            } else {
                asignaturas = getResources().getStringArray(R.array.asignaturas2);
            }
            ArrayAdapter<String> arrayAdapter= new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, asignaturas);
            final Spinner spinner=findViewById(R.id.spinner2);
            spinner.setAdapter(arrayAdapter);
            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    if (position!=0){
                        Intent intent=new Intent(getApplicationContext(),TerceraActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putString("curso", cursoEscogido);
                        bundle.putString("asig", spinner.getItemAtPosition(position).toString());
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }
                @Override
                public void onNothingSelected(AdapterView<?> parent) {

                }
            });
        }
    }

}
