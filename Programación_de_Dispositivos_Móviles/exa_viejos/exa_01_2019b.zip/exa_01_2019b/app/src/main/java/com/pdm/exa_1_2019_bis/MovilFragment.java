package com.pdm.exa_1_2019_bis;


import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.Objects;


/**
 * A simple {@link Fragment} subclass.
 */
public class MovilFragment extends Fragment {

    public interface MiListenerMovil {
        void onMovilTocado();
    }

    private MiListenerMovil miEscuchador;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        try {
            miEscuchador = (MiListenerMovil) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(Objects.requireNonNull(getActivity()).toString()
                    + " must implement MovilListener");
        }
    }

    public MovilFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_movil, container, false);
        ImageView imageView=view.findViewById(R.id.imageView4);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                miEscuchador.onMovilTocado();
            }
        });
        return view;
    }

    @Override
    public void onDetach () {
        super.onDetach();
        miEscuchador=null;
    }

}
