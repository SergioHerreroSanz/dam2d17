package com.company;

public class Contador extends Thread{

    @Override
    public void run() {
        while(!isInterrupted()){
            System.out.println("Sigo vivo");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
                return;
            }
        }
    }
}
