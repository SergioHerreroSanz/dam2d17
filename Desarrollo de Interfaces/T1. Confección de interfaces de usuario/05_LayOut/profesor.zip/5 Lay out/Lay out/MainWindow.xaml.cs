﻿using System;
using System.Configuration; 
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Media;

namespace Lay_out
{
    /// <summary>
    /// Lógica de interacción para MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private string connectionString = "";
        public int entero;
        public static int numeroAux;

        public MainWindow()
        {
            InitializeComponent();
            entero = 5;
            numeroAux = 5;

            SqlDataReader datos = null;
            connectionString = ConfigurationManager.ConnectionStrings["conexionClase"].ConnectionString;
            string sql = "";
            string idioma = ReadSetting("idiomaEs");
            DataSet etiquetas = new DataSet();

            // Obtenemos la información dinámica del label formulario 
            try
            {
                SqlConnection conexion = new SqlConnection(connectionString);
                sql = "SELECT formulario FROM dbo.Formularios";
                SqlCommand sentencia = new SqlCommand(sql, conexion);
                conexion.Open();
                datos = sentencia.ExecuteReader();
                datos.Read();

                ReadSingleRow((IDataRecord)datos);

                datos.Close();
                conexion.Close();
            } catch (Exception ex) {
                MessageBox.Show(ex.ToString());
            }

            // Obtenemos los valores de las etiquetas
            try {
                SqlConnection conexion = new SqlConnection(connectionString);
                sql = "select * from textos where idioma like '"+idioma+"';";
                SqlCommand sentencia = new SqlCommand(sql, conexion);
                conexion.Open();
                datos = sentencia.ExecuteReader();
                datos.Read();

                SelectRows(etiquetas, connectionString, sql);
                PintarLabels(etiquetas);

                datos.Close();
                conexion.Close();
            }
            catch (Exception ex) {
                MessageBox.Show(ex.ToString());
            }
        }

        /// <summary>
        /// Devuelve objeto dataset con los datos recuperados
        /// </summary>
        /// <param name="dataset"></param>
        /// <param name="connectionString"></param>
        /// <param name="queryString"></param>
        /// <returns></returns>
        private static DataSet SelectRows(DataSet dataset, string connectionString, string queryString)
        {
            using (SqlConnection connection =
                new SqlConnection(connectionString))
            {
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand(
                    queryString, connection);
                adapter.Fill(dataset);

                connection.Close();
                //dataset.Tables[0].Rows[0].ItemArray
                return dataset;
            }
        }
        
        /// <summary>
        /// Método que me devolverá el idioma de entorno a aplicar
        /// </summary>
        /// <param name="key"></param>
        private string ReadSetting(string key)
        {
            string result;
            try
            {
                var appSettings = ConfigurationManager.AppSettings;
                result = appSettings[key] ?? "Not Found";
                Console.WriteLine(result);
            }
            catch (ConfigurationErrorsException)
            {
                Console.WriteLine("Error reading app settings");
                result = "error";
            }
            return result;
        }

        /// <summary>
        /// Método que lee una fila
        /// </summary>
        /// <param name="record"></param>
        private void ReadSingleRow(IDataRecord record)
        {
            lblTitulo.Content = String.Format("{0}", record[0]);
        }

        /// <summary>
        /// Este método me va a rellenar todos los valores de los labels
        /// Recogeremos los valores del dataset y los pintaremos en el valor de la etiqueta
        /// </summary>
        /// <param name="record"></param>
        private void PintarLabels(DataSet etiquetas)
        {
            grbInformacionPersonal.Header = etiquetas.Tables[0].Rows[0].ItemArray[2].ToString();
            lblNombre.Content = etiquetas.Tables[0].Rows[1].ItemArray[2].ToString();
            lblApellidos.Content = etiquetas.Tables[0].Rows[2].ItemArray[2].ToString();
            lblCorreo.Content = etiquetas.Tables[0].Rows[3].ItemArray[2].ToString();
        }

        /// <summary>
        /// Manejador de evento de btnAceptar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnCancelar_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Manejador de evento de btnAceptar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BtnAceptar_Click(object sender, RoutedEventArgs e)
        {
        }
    }
}
