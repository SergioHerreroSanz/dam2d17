package com.pdm.p_19_intent_imc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText peso;
    private EditText altura;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button calcular = findViewById(R.id.button);
        calcular.setOnClickListener(this);
        Button ayuda = findViewById(R.id.button2);
        ayuda.setOnClickListener(this);
        peso = findViewById(R.id.editText);
        altura = findViewById(R.id.editText2);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.button2:
                Intent i = new Intent(this, SegundaActivity.class);
                startActivity(i);
                break;
            case R.id.button:
                if (peso.getText().toString().trim().length() == 0) {
                    peso.requestFocus();
                    Toast.makeText(this, "Falta peso", Toast.LENGTH_SHORT).show();
                } else {
                    if (altura.getText().toString().trim().length() == 0) {
                        altura.requestFocus();
                        Toast.makeText(this, "Falta altura", Toast.LENGTH_SHORT).show();
                    } else {
                        double kg = Double.parseDouble(peso.getText().toString());
                        double m = Double.parseDouble(altura.getText().toString()) / 100;
                        double imc = (kg / (m * m));
                        if (imc < 18.5) {
                            Toast.makeText(this,
                                    "Tu IMC es " + imc + "\n" + "Estás delgado",
                                    Toast.LENGTH_LONG).show();
                        } else {
                            if (imc < 24.9) {
                                Toast.makeText(
                                        this,
                                        "Tu IMC es " + imc + "\n"
                                                + "Tu peso es normal",
                                        Toast.LENGTH_LONG).show();
                            } else {
                                if (imc < 29.9) {
                                    Toast.makeText(
                                            this,
                                            "Tu IMC es " + imc + "\n"
                                                    + "Tienes sobrepeso",
                                            Toast.LENGTH_LONG).show();
                                } else {
                                    if (imc > 30) {
                                        Toast.makeText(
                                                this,
                                                "Tu IMC es " + imc + "\n"
                                                        + "Padeces obesidad",
                                                Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        }
                    }
                }
                break;
        }
    }
}